/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author Espectro
 */
public class Calle extends Casilla{
    
    
    Calle(int numeroCasilla,TituloPropiedad titulo){
    
        super(numeroCasilla,TipoCasilla.CALLE);
        this.titulo = titulo;
        
    }
    
    public TituloPropiedad asignarPropietario(Jugador jugador){
        
        titulo.setPropietario(jugador);
        
        return titulo;
        
    }
    
    public int pagarAlquiler(){
    
        return 0;
    }
   
    public boolean tengoPropietario(){
        return titulo.tengoPropietario();
    }
    
    @Override
    protected TipoCasilla getTipo() {
        return tipo;
    }

    @Override
    protected TituloPropiedad getTitulo() {
        return titulo;
    }
    
    @Override
    protected boolean soyEdificable(){
        return true;
    }
      
    private void setTitulo(TituloPropiedad titulo){
        this.titulo = titulo;
    }
    
    @Override
    public String toString() {
        
        String resultado;

        resultado = "Numero: " + numeroCasilla + " Coste: " + coste;
        resultado += " Tipo: " + tipo + " Titulo: " + titulo.getNombre();

       return resultado; 
    }
}
