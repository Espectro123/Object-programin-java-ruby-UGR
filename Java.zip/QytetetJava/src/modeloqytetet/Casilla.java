/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author espectro
 */
public class Casilla {
    
    protected int numeroCasilla;
    protected int coste;
    protected TipoCasilla tipo;
    protected TituloPropiedad titulo;
    
    Casilla(){
    
    }
    
    Casilla(int numeroCasilla,TipoCasilla tipo){
        
        this.numeroCasilla = numeroCasilla;
        this.tipo = tipo;
        this.coste = 0;
        this.titulo = null;
        
    }
    
    @Override
    public String toString() {
        
        String resultado = "";
        
        if(titulo == null){
            resultado = "Numero: " + numeroCasilla + " tipo: " + tipo;
        }else{
            resultado = "Numero: " + numeroCasilla + " Coste: " + coste;
            resultado += " Tipo: " + tipo + " Titulo: " + titulo.getNombre();
        }
        
       return resultado; 
    }

    public int getNumeroCasilla() {
        return numeroCasilla;
    }

    public int getCoste() {
        return coste;
    }

    protected TipoCasilla getTipo() {
        return tipo;
    }

    protected TituloPropiedad getTitulo() {
        return titulo;
    }

    protected boolean soyEdificable(){
        
        boolean respuesta = false;
        
        if(tipo == TipoCasilla.CALLE)
            respuesta = true;
        
        return respuesta;
    }
    
    boolean propietarioEncarcelado(){
        return titulo.propietarioEncarcelado();
    }
    
    public void setCoste(int coste){
        this.coste = coste;
    }
    
    public boolean tengoPropietario(){
        return titulo.tengoPropietario();
    }
    
}
