    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

import java.util.ArrayList;

/**
 *
 * @author espectro
 */
public class Tablero{
    
    private ArrayList<Casilla> casillas;
    private Casilla carcel;
    
    
    Tablero(){
        
        casillas = new ArrayList<Casilla>(20);
        inicializar();
        carcel = new Casilla(9,TipoCasilla.CARCEL);
    
    }
    
    private void inicializar(){
        
        Casilla casilla = new OtraCasilla(0,TipoCasilla.SALIDA);
        casillas.add(casilla);
        
        TituloPropiedad titulo = new TituloPropiedad("La parra",0.5f,300,100,200,50);
        casilla = new Calle(1,titulo);
        casillas.add(casilla);
        
        titulo = new TituloPropiedad("Las jarras",1.0f,600,230,400,120);
        casilla = new Calle(2,titulo);
        casillas.add(casilla);
        
        casilla = new OtraCasilla(3,TipoCasilla.SORPRESA);
        casillas.add(casilla);

        titulo = new TituloPropiedad("La academia",1.5f,1200,400,800,250);
        casilla = new Calle(4,titulo);
        casillas.add(casilla);
        
        titulo = new TituloPropiedad("El continental",1.0f,1800,600,1200,350);
        casilla = new Calle(5,titulo);
        casillas.add(casilla);
        
        titulo = new TituloPropiedad("El dominos",2.0f,2500,900,2000,500);
        casilla = new Calle(6,titulo);
        casillas.add(casilla);
        
        casilla = new OtraCasilla(7,TipoCasilla.IMPUESTO);
        casillas.add(casilla);
        
        titulo = new TituloPropiedad("Erasmus",5.0f,5000,1000,3500,3000);
        casilla = new Calle(8,titulo);
        casillas.add(casilla);
        
        //Nombre Factor Compra alquiler hipoteca edificar
        casilla = new OtraCasilla(9,TipoCasilla.CARCEL);
        carcel = casilla;
        
        
        titulo = new TituloPropiedad("Memes de gatos",2.5f,3000,1200,2200,700);
        casilla = new Calle(10,titulo);
        casillas.add(casilla);
        
        titulo = new TituloPropiedad("Memes de pelis",3.0f,4000,1800,3200,1000);
        casilla = new Calle(11,titulo);
        casillas.add(casilla);
        
        casilla = new OtraCasilla(12,TipoCasilla.SORPRESA);
        casillas.add(casilla);
        
        casilla = new OtraCasilla(13,TipoCasilla.PARKING);
        casillas.add(casilla);
        
        titulo = new TituloPropiedad("Chocobos",0.0f,5000,4000,4200,1500);
        casilla = new Calle(14,titulo);
        casillas.add(casilla);
        
        titulo = new TituloPropiedad("Matalocalypse",10.0f,10000,2300,0,1500);
        casilla = new Calle(15,titulo);
        casillas.add(casilla);
        
        casilla = new OtraCasilla(16,TipoCasilla.SORPRESA);
        casillas.add(casilla);
        
        titulo = new TituloPropiedad("Plan Propio",5.0f,5000,1000,3500,3000);
        casilla = new Calle(17,titulo);
        casillas.add(casilla);
        
        titulo = new TituloPropiedad("Grado de II",12.0f,8000,3000,7200,1900);
        casilla = new Calle(18,titulo);
        casillas.add(casilla);
        
        casilla = new OtraCasilla(19,TipoCasilla.JUEZ);
        casillas.add(casilla); 
        
     
    }
    
    public ArrayList<Casilla> getCasillas() {
        return casillas;
    }

    public Casilla getCarcel() {
        return carcel;
    }
    
    //Devuelve true si numeroCasilla es la casilla de carcel
    boolean esCasillaCarcel(int numeroCasilla){
        
        boolean respuesta = false;
        
        if(numeroCasilla == carcel.getNumeroCasilla())
            respuesta = true;
        
        return respuesta;
    }
    
    //Devuelve una casilla si existe. Si no devuelve null
    Casilla obtenerCasillaNumero(int numeroCasilla){
        
        Casilla casilla;
        
        if(numeroCasilla > 0 && numeroCasilla < casillas.size()-1)
            casilla = casillas.get(numeroCasilla);
        else
            casilla = null;
     
        return casilla;
    }
    
    Casilla obtenerCasillaFinal(Casilla casilla, int desplazamiento){
        
        int casillaDestino = casilla.getNumeroCasilla() + desplazamiento;
        
        if(casillaDestino > casillas.size()-1)
            casillaDestino = casillaDestino % (casillas.size()-1);
        
        return casillas.get(casillaDestino);
        
    }
     
    @Override
    public String toString() {
        
        String resultado = "";
        
        for(Casilla c: this.casillas){
            resultado += c.toString();
        }
        
        resultado += this.carcel.toString();
        
        return resultado;
    }
    
    
        
        
    
}
