    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;
import java.util.ArrayList;
import java.util.Random;
import java.util.*;

/**
 *
 * @author espectro
 */
public class Qytetet {
    
    
    private static final Qytetet INSTANCE = new Qytetet();
    
    private ArrayList<Sorpresa> mazo;
    private ArrayList<Jugador> jugadores;
    private Jugador jugadorActual;
    private Tablero tablero;
    private Sorpresa cartaActual;
    private Dado dado;
    
    public int MAX_JUGADORES;   
    public int NUM_CASILLAS;
    int NUM_SORPRESAS;
    int PRECIO_LIBERTAD;
    int SALDO_SALIDA;
    EstadoJuego estadoJuego;
    
    
    public static Qytetet getInstance(){
        return INSTANCE;
    }
    
    private Qytetet(){
        
        mazo = new ArrayList<>();
        jugadores = new ArrayList<>();
        jugadorActual = new Jugador();
        
        MAX_JUGADORES = 4;
        NUM_CASILLAS = 20;
        NUM_SORPRESAS = 10;
        PRECIO_LIBERTAD = 200;
        SALDO_SALIDA = 1000;
    
    }

    @Override
    public String toString() {
        return "Qytetet{" + "mazo=" + mazo + ", jugadores=" + jugadores + ", jugadorActual=" + jugadorActual + ", tablero=" + tablero + ", cartaActual=" + cartaActual + '}';
    }
    
    //Devuelve un array list con las cartas de sorpresa del mazo
    ArrayList<Sorpresa> getMazo(){
        return this.mazo;
    }
    
    Tablero getTablero(){
        return this.tablero;
    }
    
    //Inicializa el vector Mazo con 10 cartas de sorpresa
    void inicializarCartasSorpresa(){
        Sorpresa carta;
        String descripcion;
        
        //Carta numero 1
        descripcion = "Un pterodacti se tropieza contigo y te paga una indenizacion de 1000 euros";
        carta = new Sorpresa(descripcion,1000,TipoSorpresa.PAGARCOBRAR);
        mazo.add(carta);
        
        //Carta numero 2
        descripcion = "Un tio con un audi se choca contigo y su abogado te hace pagar 1000 euros";
        carta = new Sorpresa(descripcion,-1000,TipoSorpresa.PAGARCOBRAR);
        mazo.add(carta);
        
        //Carta numero 3
        descripcion = "Haces un chiste sobre un dictador en twitter y el gobierno te envia a la carcel";
        carta = new Sorpresa(descripcion,9,TipoSorpresa.IRACASILLA);
        mazo.add(carta);
        
        //Carta numero 4
        descripcion = "Los idiotas de tus amigos deciden quedar y tienes que ir a Einstein";
        carta = new Sorpresa(descripcion,3,TipoSorpresa.IRACASILLA);
        mazo.add(carta);
        
        //Carta numero 5
        descripcion = "Te dan la beca erasmus en polopos. Enhrabuena!. LLeva abrigo";
        carta = new Sorpresa(descripcion,19,TipoSorpresa.IRACASILLA);
        mazo.add(carta);
        
        //Carta numero 6
        descripcion = "La junta de andalucia dicta que tus casas estan mal. Paga 100 por cada casa.";
        carta = new Sorpresa(descripcion,-100,TipoSorpresa.PORCASAHOTEL);
        mazo.add(carta);
        
        //Carta numero 7
        descripcion = "Pintas graffitis en todas tus casas y las conviertes en una galeria. Ganas 100 por cada casa";
        carta = new Sorpresa(descripcion,100,TipoSorpresa.PORCASAHOTEL);
        mazo.add(carta);
       
        //Carta numero 8
        descripcion = "Tus amiguis te dejan dinero para cenar. Recibes 10 por cada jugador";
        carta = new Sorpresa(descripcion,10,TipoSorpresa.PORJUGADOR);
        mazo.add(carta);
        
        //Carta numero 9
        descripcion = "Tus amiguis te piden el dinero que te dejaron hace tiempo. Pierdas 10 por cada jugador";
        carta = new Sorpresa(descripcion,-10,TipoSorpresa.PORJUGADOR);
        mazo.add(carta);
        
        //Carta numero 10
        descripcion = "El gobierno ha decidido que escanear puertos no es un delito. Sales de la carcel";
        carta = new Sorpresa(descripcion,0,TipoSorpresa.SALIRCARCEL);
        mazo.add(carta);
        
        //Carta numero 11. Añadida para el especulador
        descripcion = "Te vuelves especulador con una fianza de 3000.";
        carta = new Sorpresa(descripcion,3000,TipoSorpresa.CONVERTIRME);
        mazo.add(carta);
        
        //Carta numero 12. Aladida para el especulador
        descripcion = "Te vuelves especulador con uan fianza de 5000.";
        carta = new Sorpresa(descripcion,5000,TipoSorpresa.CONVERTIRME);
        mazo.add(carta);
        
    }
    
    private void iniciarlizarTablero(){
        this.tablero = new Tablero();
    }
    
    void actuarSiEnCasillaEdificable(){
        
        boolean deboPagar = jugadorActual.deboPagarAlquiler();
        boolean tengoPropietario = false;
        
        if(deboPagar){
            
            jugadorActual.pagarAlquiler();
            
            if(jugadorActual.getSaldo() <= 0){
                
                setEstadoJuego(EstadoJuego.ALGUNJUGADORENBANCAROTA);
                
            }
            
        }
        
        Casilla casilla = obtenerCasillaJugadorActual();
        
        tengoPropietario = casilla.tengoPropietario();
        
        if(estadoJuego != estadoJuego.ALGUNJUGADORENBANCAROTA){
            
            if(tengoPropietario){
                
                setEstadoJuego(estadoJuego.JA_PUEDEGESTIONAR);
                
            }else{
                
                setEstadoJuego(estadoJuego.JA_PUEDECOMPRAROGESTIONAR);
                
            }
            
        }
        
    }
    
    void setEstadoJuego(EstadoJuego juego){
        
        estadoJuego = juego;
        
    }
    
    void actuarSiEnCasillaNoEdificable(){
        
        Casilla casillaActual;
        
        setEstadoJuego(estadoJuego.JA_PUEDEGESTIONAR);
        
        casillaActual = jugadorActual.getCasillaActual();
        
        if(casillaActual.getTipo() == TipoCasilla.IMPUESTO){
            
            jugadorActual.pagarImpuesto();
            
            if(jugadorActual.getSaldo() <= 0){
                
                setEstadoJuego(EstadoJuego.ALGUNJUGADORENBANCAROTA);
                
            }
            
        }else if(casillaActual.getTipo() == TipoCasilla.JUEZ){
            
            encarcelarJugador();
            
        }else if(casillaActual.getTipo() == TipoCasilla.SORPRESA){
            
            cartaActual = mazo.remove(0);
            setEstadoJuego(EstadoJuego.JA_CONSORPRESA);
            
        }
        
    }
 
    public void aplicarSorpresa(){
        
        setEstadoJuego(EstadoJuego.JA_PUEDEGESTIONAR);
        
        if(cartaActual.getTipo() == TipoSorpresa.SALIRCARCEL){
            
            jugadorActual.setCartaLibertad(cartaActual);
            
        }else if(cartaActual.getTipo() == TipoSorpresa.PAGARCOBRAR){
            
            jugadorActual.modificarSaldo(cartaActual.getValor());
            
            if(jugadorActual.getSaldo() <= 0){
                
                setEstadoJuego(EstadoJuego.ALGUNJUGADORENBANCAROTA);
                
            }
            
        }else if(cartaActual.getTipo() == TipoSorpresa.IRACASILLA){
            
            int valor = cartaActual.getValor();
            boolean casillaCarcel = tablero.esCasillaCarcel(valor);
            
            if(casillaCarcel){
                
                encarcelarJugador();
                
            }else{
                
                mover(valor);
                
            }
            
        }else if(cartaActual.getTipo() == TipoSorpresa.PORCASAHOTEL){
            
            int cantidad = cartaActual.getValor();
            int numeroTotal = jugadorActual.cuantasCasasHotelesTengo();
            jugadorActual.modificarSaldo(cantidad*numeroTotal);
            
            if(jugadorActual.getSaldo() <= 0){
                
                setEstadoJuego(EstadoJuego.ALGUNJUGADORENBANCAROTA);
                
            }
            
        }else if(cartaActual.getTipo() == TipoSorpresa.PORJUGADOR){
            
            for(Jugador jugador: jugadores){
                
                if(jugador != jugadorActual){
                    
                    jugador.modificarSaldo(cartaActual.getValor());
                    
                    if(jugador.getSaldo() <= 0){
                
                        setEstadoJuego(EstadoJuego.ALGUNJUGADORENBANCAROTA);
                
                    }
                    
                    jugadorActual.modificarSaldo(-cartaActual.getValor());
                    
                    if(jugadorActual.getSaldo() <= 0){
                
                        setEstadoJuego(EstadoJuego.ALGUNJUGADORENBANCAROTA);
                
                    }
                    
                }
                
                
            }
            
        }else if(cartaActual.getTipo() == TipoSorpresa.CONVERTIRME){
            
            Especulador nuevoEspecualdor;
            nuevoEspecualdor = jugadorActual.convertirme(cartaActual.getValor());
            int posicion_jugador = obtenerNumeroJugador();
            jugadores.set(posicion_jugador, nuevoEspecualdor);
            
        }
        
    }
    
    //Obtienes la posicion del jugador actual
    private int obtenerNumeroJugador(){
        
        int posicion = 0;
        boolean continua = true;
        
        for(Jugador jugador: jugadores){
        
            if(jugador != jugadorActual && continua){
                
                posicion++;
                
            }else{
            
                continua = false;
                
            }
            
        }
        
        return posicion;
    }
    
    public boolean aplicarHipoteca(int numeroCasilla){
        
        return true;
        
    }
    
    public boolean comprarTituloPropiedad(){
        
        int costeCompra = jugadorActual.getCasillaActual().getCoste();
        boolean comprado = false;
        TituloPropiedad titulo;
        
        if(costeCompra < jugadorActual.getSaldo()){
            
            titulo = ((Calle)jugadorActual.getCasillaActual()).asignarPropietario(jugadorActual);
            
            comprado = true;
            
            jugadorActual.getPropiedades().add(titulo);
            
            jugadorActual.modificarSaldo(-costeCompra);
            
        }
        
        if(comprado)
            setEstadoJuego(EstadoJuego.JA_PUEDEGESTIONAR);
        
        return comprado;
    }
    
    public boolean edificarCasa(int numeroCasilla){
        
        boolean edificada = false;
        
        Casilla casilla = tablero.getCasillas().get(numeroCasilla);
        
        TituloPropiedad titulo = casilla.getTitulo();
    
        edificada = jugadorActual.edificarCasa(titulo);
        
        if(edificada)
            setEstadoJuego(EstadoJuego.JA_PUEDEGESTIONAR);
        
        return edificada;
    }
    
    public boolean edificarHotel(int numeroCasilla){
        return true;
    }
    
    private void encarcelarJugador(){
        
        if(!jugadorActual.deboIrACarcel()){
            
            Casilla casillaCarcel = tablero.getCarcel();
            
            jugadorActual.irACarcel(casillaCarcel);
           
            
            setEstadoJuego(EstadoJuego.JA_ENCARCELADO);
         
        }else{
            
            Sorpresa carta = jugadorActual.devolverCartaLibretad();
            
            mazo.add(carta);
            
            setEstadoJuego(EstadoJuego.JA_PUEDEGESTIONAR);
            
        }
        
    }
    
    public Sorpresa getCartaActual(){
        
        return this.cartaActual;
        
    }
    
    Dado getDado(){
        
        return this.dado;
                
    }
    
    Jugador getJugadorActual(){
        
        return this.jugadorActual;
        
    }
    
    public ArrayList<Jugador> getJugadores(){
        
        return this.jugadores;
        
    }
    
    public int getValorDado(){
        return dado.getValor();
    }
    
    public void hipotecarPropiedad(int numeroCasilla){
        
        Casilla casilla = tablero.obtenerCasillaNumero(numeroCasilla);
        
        TituloPropiedad titulo = casilla.getTitulo();
        
        jugadorActual.hipotecarPropiedad(titulo);
        
        
        
    }
    
    public void inicializarJuego(ArrayList<String> nombres){
        
        inicializarJugadores(nombres);
        iniciarlizarTablero();
        inicializarCartasSorpresa();
        salidaJugadores();
        
    }
    
    private void inicializarJugadores(ArrayList<String> nombres){
        
        for(String nombreJugador: nombres){
            
            Jugador nuevoJugador = new Jugador(nombreJugador);
            jugadores.add(nuevoJugador);
            
        }
        
    }
    
    public boolean intentarSalirDeLaCarcel(MetodoSalirCarcel metodo){
        
        boolean encarcelado = true;
        
        if(metodo == MetodoSalirCarcel.TIRANDODADO){
            
            int resultado = tirarDado();
            
            if(resultado >= 5){
                
                jugadorActual.setEncarcelado(false);
                
            }
            
        }else if(metodo == MetodoSalirCarcel.PAGANDOLIBERTAD){
            
            jugadorActual.pagarLibertad(PRECIO_LIBERTAD);
            
        }
        
        encarcelado = jugadorActual.getEncarcelado();
        
        if(encarcelado)
            setEstadoJuego(EstadoJuego.JA_ENCARCELADO);
        else
            setEstadoJuego(EstadoJuego.JA_PREPARADO);
        
        return !encarcelado;
    }
    
    public void jugar(){
      
       Casilla casillaFinal;
       int tirada = tirarDado();
       casillaFinal = getTablero().obtenerCasillaFinal(obtenerCasillaJugadorActual(), tirada);
       mover(casillaFinal.getNumeroCasilla());
        
    }
    
    void mover(int numCasillaDestino){
        
        Casilla casillaInicial = jugadorActual.getCasillaActual();
        
        Casilla casillaFinal = tablero.obtenerCasillaNumero(numCasillaDestino);
        
        jugadorActual.setCasillaActual(casillaFinal);
        
        if(numCasillaDestino < casillaInicial.getNumeroCasilla()){
            
            jugadorActual.modificarSaldo(SALDO_SALIDA);
            
        }
        
        if(casillaFinal.soyEdificable()){
            
            actuarSiEnCasillaEdificable();
            
        }else{
            
            actuarSiEnCasillaNoEdificable();
            
        }
        
    }
    
    public Casilla obtenerCasillaJugadorActual(){
        return jugadorActual.getCasillaActual();
    }
    
    public ArrayList<Casilla> obtenerCasillasTablero(){
        
        ArrayList<Casilla> tablero = null;
        
        return tablero;
        
    }
    
    public ArrayList<Integer> obtenerPropiedadesJugador(){
        
        ArrayList<TituloPropiedad> propiedades;
        ArrayList<Casilla> casillas;
        ArrayList<Integer> resultado = new ArrayList();
        
        String nombre;
        propiedades = jugadorActual.getPropiedades(); //Obtengo las propiedades del jugador
        casillas = getTablero().getCasillas();        //Obtengo las casillas
        
        for(TituloPropiedad propiedad: propiedades){
            
            nombre = propiedad.getNombre();
            
            for(Casilla casilla: casillas){
                
                if(nombre.equals(casilla.getTitulo().getNombre())){
                    
                    resultado.add(casilla.getNumeroCasilla());
                    
                }
                
            }
            
        }
        
        return resultado;
        
    }
    
    public ArrayList<Integer> obtenerPropiedadesJugadorSegunEstadoHipoteca(boolean estadoHipoteca){
        
        ArrayList<TituloPropiedad> propiedades;
        ArrayList<Casilla> casillas;
        ArrayList<Integer> resultado = new ArrayList();
        
        String nombre;
        propiedades = jugadorActual.getPropiedades(); //Obtengo las propiedades del jugador
        casillas = getTablero().getCasillas();        //Obtengo las casillas
        
        if(estadoHipoteca){
            
            //Elimino las propiedades que no este hipoetcadas
            for(TituloPropiedad propiedad: propiedades){
                
                if(!propiedad.getHipotecado())
                    propiedades.remove(propiedad);
                
            }
            
            for(TituloPropiedad propiedad: propiedades){
            
                nombre = propiedad.getNombre();
            
                for(Casilla casilla: casillas){
                
                    if(nombre.equals(casilla.getTitulo().getNombre())){
                    
                        resultado.add(casilla.getNumeroCasilla());
                    
                    }
                
                }
            
            }
            
        }else{
            
             //Elimino las propiedades que esten hipotecadas
            for(TituloPropiedad propiedad: propiedades){
                
                if(propiedad.getHipotecado())
                    propiedades.remove(propiedad);
                
            }
            
             for(TituloPropiedad propiedad: propiedades){
            
                nombre = propiedad.getNombre();
            
                for(Casilla casilla: casillas){
                
                    if(nombre.equals(casilla.getTitulo().getNombre())){
                    
                        resultado.add(casilla.getNumeroCasilla());
                    
                    }
                
                }
            
            }
            
        }
        
        
       
        return resultado;
    }
    
    public void obtenerRanking(){
        
        Collections.sort(jugadores);
        
    }
    
    public EstadoJuego getEstado(){
    
        return estadoJuego;
        
    }
    
    public int obteneSaldoJugadorActual(){
        return jugadorActual.getSaldo();
    }
    
    private void salidaJugadores(){
        
        estadoJuego = EstadoJuego.JA_PREPARADO;
        //Obtengo la casilla inicial a traves del tablero
        Casilla casillaInicial = getTablero().getCasillas().get(0);
        
        //Obtengo el jugador  de forma aleatoria
        Random rand = new Random();
        int jugador_elegido = rand.nextInt(jugadores.size()) + 0;
        
        //Pongo a los jugadores en la casilla de salida
        for(Jugador jugador: jugadores){
            
            jugador.setCasillaActual(casillaInicial);
            
        }
        
        //Asigno el jugador actual
        jugadorActual = jugadores.get(jugador_elegido);
        
        
    }
    
    private void setCartaActual(Sorpresa cartaActual){
        
        this.cartaActual = cartaActual;
    
    }
    
    public void siguienteJugador(){
        
        int posicion = 0;
        boolean encontrado = true;
        
        for(Jugador jugador: jugadores){
            
            if(jugador.compareTo(jugadorActual) == 0){
                
               encontrado = false;
                
            }else if(encontrado){
                
                posicion++;
                
            }
            
        }
        
        posicion = (posicion+1)%(jugadores.size()-1);
        
        jugadorActual = jugadores.get(posicion);
        
        if(jugadorActual.getEncarcelado()){
            estadoJuego = EstadoJuego.JA_ENCARCELADOCONOPCIONDELIBERTAD;
        }else{
            estadoJuego = EstadoJuego.JA_PREPARADO;
        }
        
        
    }
    
    int tirarDado(){
        return dado.tirar();
    }
    
    public void venderPropiedad(int numeroCasilla){
    
        Casilla casilla = tablero.obtenerCasillaNumero(numeroCasilla);
        
        jugadorActual.venderPropiedad(casilla);
        
        setEstadoJuego(EstadoJuego.JA_PUEDEGESTIONAR);
        
        
        
    }
    
    
}
