/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author espectro
 */
public class Sorpresa {
    
    private String texto;
    private int valor;
    private TipoSorpresa tipo;
    
    Sorpresa(String texto,int valor,TipoSorpresa tipo){
     this.texto = texto;
     this.valor = valor;
     this.tipo = tipo;
    }
    
    
    String getTexto(){
        return this.texto;
    }
    
    int getValor(){
        return this.valor;
    }
    
    TipoSorpresa getTipo(){
        return this.tipo;
    }
    
    @Override
    public String toString(){
        return "Sorpresa{" + "texto=" + texto + " valor=" + Integer.toString(valor) + ", tipo=" + tipo + "}";
    }
    
    
    
}
