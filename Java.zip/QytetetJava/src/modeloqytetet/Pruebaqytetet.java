/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author espectro
 */
public class Pruebaqytetet {

    /**
     * @param args the command line arguments
     */
        //Metodo que devuelve las sorpresas con valor mayor que 0
    private static ArrayList<Sorpresa> ValorMayorQueCero(ArrayList<Sorpresa> mazo){
        
        ArrayList<Sorpresa> resultado = new ArrayList<>();
        
        for(Sorpresa s: mazo){
            
            if(s.getValor() > 0)
                resultado.add(s);
                        
        }
        
        return resultado;
    }
    
    //Metodo que devuelve las sorpresas de tipo IRACASILLA
    private static ArrayList<Sorpresa> SorpresasDeIrACasilla(ArrayList<Sorpresa> mazo){
        
        ArrayList<Sorpresa> resultado = new ArrayList<>();
        
        for(Sorpresa s: mazo){
            
            if(s.getTipo() == TipoSorpresa.IRACASILLA)
                resultado.add(s);
            
        }
        
        return resultado;
    }
    
    //Metodo que devuelve cualquier tipo de sorpresa
    private static ArrayList<Sorpresa> ObtenerTipoSorpresa(ArrayList<Sorpresa> mazo,TipoSorpresa tipo){
        
        ArrayList<Sorpresa> resultado = new ArrayList<>();
        
        for(Sorpresa s: mazo){
            
            if(s.getTipo() == tipo)
                resultado.add(s);
            
        }
        
        return resultado;
    }
    
    //Obtiene el numero de jugadores y sus nombres del usuario y devuelve un Array de String con sus nombres
    private static ArrayList<String> getNombreJugadores(){
        
        ArrayList<String> nombres = new ArrayList<String>();
        
        int numeroJugadores = 0;
        
        Scanner in = new Scanner(System.in);
        
        System.out.println("Ingresa el numero de jugadores");
        
        numeroJugadores = in.nextInt();
        
        System.out.println("Ingresa el nombre de los jugadores");
        
        for(int i = 0; i <= numeroJugadores; i++){
            
            nombres.add(in.nextLine());
            
        }
        
        return nombres;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("\n----- Practica 1 -----\n");
        
        Qytetet juego = Qytetet.getInstance();
        juego.inicializarCartasSorpresa();
        ArrayList<Sorpresa> prueba = new ArrayList<>();
        prueba = juego.getMazo();
        
        //Obtengo todas las sorpresas
        for(Sorpresa s: prueba){
            
            System.out.println(s.toString());
            
        }
        
        //Sorpresas con valores mayores de 0
        System.out.println("------Valores mayores que 0------");
        for(Sorpresa s: ValorMayorQueCero(prueba)){
            
            System.out.println(s.toString());
            
        }
        
        //Sorpresas de tipo Ir a la casilla
        System.out.println("------Sorpresas de Ir a la casilla------");
        for(Sorpresa s: SorpresasDeIrACasilla(prueba)){
            
            System.out.println(s.toString());
            
        }
        
        //Sorpresa de cualquier tipo
        System.out.println("------Obtener tipo de Sorpresa------");
        for(Sorpresa s: ObtenerTipoSorpresa(prueba,TipoSorpresa.PORCASAHOTEL)){
            
            System.out.println(s.toString());
            
        }
        
        System.out.println("\n----- Practica 1 -----\n");
        Tablero tablero = new Tablero();
        for(Casilla casilla : tablero.getCasillas()){
            
            System.out.println(casilla.toString());
            
        }
        
        
        System.out.println("\n----- Practica 2 -----\n");
        
            ArrayList<String> nombres = getNombreJugadores();
    
            for(String nombre : nombres){
    
                System.out.println(nombre);
                
            }
            
        System.out.println("\n----- Practica 3 -----\n");
        
    }
    

    
}
