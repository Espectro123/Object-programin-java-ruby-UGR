/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author Espectro
 */
public class Especulador extends Jugador{
    
    private int fianza;
    
    
    Especulador(Jugador jugador, int fianza){
        
        this.fianza = fianza;
        this.encarcelado = jugador.encarcelado;
        this.nombre = jugador.nombre;
        this.saldo = jugador.saldo;
        this.propiedades = jugador.propiedades;
        this.casillaActual = jugador.casillaActual;
        this.cartaLibertad = this.cartaLibertad;
        
    }
    
    @Override
    protected void pagarImpuesto(){
    
        this.saldo = this.saldo - casillaActual.getCoste()/2;
        
    }
    
    @Override
    protected Especulador convertirme(int fianza){
        return this;
    }
     
    @Override
    protected boolean deboIrACarcel(){
        
        boolean respuesta = false;
        
        if(super.deboIrACarcel() && !pagarFianza(   )){
        
            respuesta = true;
            
        }
        
        return respuesta;    
    }
    
    private boolean pagarFianza(){
        
        boolean respuesta = false;
        
        if(saldo >= fianza){
        
            saldo = saldo - fianza;
            respuesta = true;
            
        }
        
        return respuesta;
    }

    @Override
    protected boolean puedoEdificarCasa(TituloPropiedad titulo){
    
        boolean respuesta = false;
        
        if(titulo.getNumCasas() < 8)
            respuesta = true;
        
        return respuesta;
    }
    
    @Override
    protected boolean puedoEdificarHotel(TituloPropiedad titulo){
        
        boolean respuesta = false;
        
        if(titulo.getNumCasas() >= 4 && titulo.getNumHoteles() < 8)
            respuesta = true;
        
        return respuesta;
    }
    
    @Override
    public String toString(){
        
        String respuesta;
        
        respuesta = super.toString();
        
        respuesta += " Fianza: " + fianza;
        
        return respuesta;
    }
}


