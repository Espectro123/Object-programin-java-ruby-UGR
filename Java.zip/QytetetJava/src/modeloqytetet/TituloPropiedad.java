/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

/**
 *
 * @author espectro
 */
public class TituloPropiedad {

    private String nombre;
    private boolean hipotecado;
    private float factorRevalorizacion;
    private int precioCompra;
    private int alquilerBase;
    private int hipotecaBase;
    private int precioEdificar;
    private int numCasas;
    private int numHoteles;
    private Jugador propietario;
    
    TituloPropiedad(String nombre,float factorRevalorizacion,int precioCompra,int alquilerBase,int hipotecaBase,int precioEdificar){
    
        this.nombre = nombre;
        this.factorRevalorizacion = factorRevalorizacion;
        this.precioCompra = precioCompra;
        this.alquilerBase = alquilerBase;
        this.hipotecaBase = hipotecaBase;
        this.precioEdificar = precioEdificar;
        this.numCasas = 0;
        this.numHoteles = 0;
        this.hipotecado = false;
        
    }

    public String getNombre() {
        return nombre;
    }

    public boolean getHipotecado() {
        return hipotecado;
    }
    
    public void setHipotecado(boolean valor){
        this.hipotecado = valor;
    }

    public float getFactorRevalorizacion() {
        return factorRevalorizacion;
    }

    public int getPrecioCompra() {
        return precioCompra;
    }

    public int getAlquilerBase() {
        return alquilerBase;
    }

    public int getHipotecaBase() {
        return hipotecaBase;
    }

    public int getPrecioEdificar() {
        return precioEdificar;
    }

    public int getNumCasas() {
        return numCasas;
    }

    public int getNumHoteles() {
        return numHoteles;
    }
    
    @Override
    public String toString(){
        
        String resultado;
        
        resultado = "TituloPropiedad{" + "nombre=" + nombre + ", Propietatio=" + propietario.getNombre() + ", hipotecado=" + hipotecado + ", factorRevalorizacion=" + factorRevalorizacion + ", precioCompra=" + precioCompra + ", alquilerBase=" + alquilerBase + ", hipotecaBase=" + hipotecaBase + ", precioEdificar=" + precioEdificar + ", numCasas=" + numCasas + ", numHoteles=" + numHoteles + '}';
        
        return resultado;
        
    }
    
    int calcularCosteCancelar(){
        
        return 0;
        
    }
    
    int calcularCosteHipotecar(){
              
        return hipotecaBase + numCasas * hipotecaBase  + numHoteles * hipotecaBase;
        
    }
    
    int calcularImporteAlquiler(){
        
        
        return 0;
    }
    
    int calcularPrecioVenta(){
        
        return precioCompra + (numCasas + numHoteles) * precioEdificar * (int)factorRevalorizacion;
        
    }
    
    
    void cacelarHipoteca(){
        
    }
    
    void cobrarAlquiler(int coste){
        
    }
    
    
    void edificarCasa(){
        
    }
    
    void edificarHotel(){
        
    }
    
    Jugador getPropietario(){
        
        return this.propietario;
        
    }
    
    int hipotecar(){

        setHipotecada(true);
        
        return calcularCosteHipotecar();
    }
    
    int pagarAlquiler(){

        int costeAlquiler = calcularImporteAlquiler();
        propietario.modificarSaldo(costeAlquiler);
        return costeAlquiler;
    }
    
    
    boolean propietarioEncarcelado(){
        
        boolean respuesta = false;
        
        if(propietario.getEncarcelado())
            respuesta = true;
        
        return respuesta;
        
    }
    
    
    void setHipotecada(boolean hipotecada){
        
        
        
    }
    
    void setPropietario(Jugador propietario){
        
        this.propietario = propietario;
        
    }
    
    boolean tengoPropietario(){
        
        boolean respuesta = false;
        
        if(propietario != null)
            respuesta = true;
        
        return respuesta;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
