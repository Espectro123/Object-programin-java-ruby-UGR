/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;

import java.util.ArrayList;



/**
 *
 * @author espectro
 */
public class Jugador implements Comparable{
    
    protected boolean encarcelado;
    protected String nombre;
    protected int saldo;
    protected ArrayList<TituloPropiedad> propiedades = new ArrayList<TituloPropiedad>();
    protected Casilla casillaActual;
    protected Sorpresa cartaLibertad;
    
    Jugador(){
        this.saldo = 7500;
        this.encarcelado = false;
    }
    
    Jugador(String nombre){
        
        this.nombre = nombre;
        this.saldo = 7500;
        this.encarcelado = false;
        
    }
       
    boolean cancelarHipoteca(TituloPropiedad titulo){
        
        boolean resultado = false;
        
        return resultado;
    }
    
    boolean comprarTituloPropiedad(){
        
        boolean resultado = false;
        
            
        
        return resultado;
    }
    
    int cuantasCasasHotelesTengo(){
         
        int totalCasasHoteles = 0;
        
        for(TituloPropiedad propiedad : propiedades){
        
            totalCasasHoteles += propiedad.getNumCasas();
            totalCasasHoteles += propiedad.getNumHoteles();
            
        }
        
        return totalCasasHoteles;
    }
    
    protected Especulador convertirme(int fianza){
    
        Especulador nuevoEspeculador;
        
        nuevoEspeculador = new Especulador(this,fianza);
        
        return nuevoEspeculador;
    }
    
    boolean deboPagarAlquiler(){
        
        boolean deboPagar = false;
        boolean esDeMiPropiedad = false;
        boolean tienePropietario = false;
        boolean estaHipotecada = false;
        boolean estaEncarcelado = false;
        
        TituloPropiedad titulo = casillaActual.getTitulo();
        
        esDeMiPropiedad = esDeMiPropiedad(titulo);
        
        if(!esDeMiPropiedad){
            
            tienePropietario = titulo.tengoPropietario();
            
            if(tienePropietario){
                
                estaEncarcelado = titulo.propietarioEncarcelado();
                
                if(!estaEncarcelado){
                    
                    estaHipotecada = titulo.getHipotecado();
                    
                    if(!estaHipotecada){
                        
                        deboPagar = true;
                        
                    }
                    
                }
                
            }
            
        }
        
        return deboPagar;
    }
    
    protected boolean deboIrACarcel(){
        return !tengoCartaLibertad();
    }
    
    Sorpresa devolverCartaLibretad(){
        
                
        return null;
    }
   

    boolean edificarCasa(TituloPropiedad titulo){
        
        boolean edificada = false;
        
        int numCasas = titulo.getNumCasas();
        
        if(puedoEdificarCasa(titulo)){
            
            int costeEdificar = titulo.getPrecioEdificar();
            
            if(tengoSaldo(costeEdificar)){
                
                titulo.edificarCasa();
                numCasas = numCasas + 1;
                modificarSaldo(-costeEdificar);
                edificada = true;
            }
            
        }
        
        return edificada;
    }
    
    boolean edificarHotel(TituloPropiedad titulo){
        
        boolean edificada = false;
        
        int numHoteles = titulo.getNumHoteles();
        
        if(puedoEdificarHotel(titulo)){
            
            int costeEdificar = titulo.getPrecioEdificar();
            
            if(tengoSaldo(costeEdificar)){
                
                titulo.edificarHotel();
                modificarSaldo(-costeEdificar);
                edificada = true;
            }
            
        }
        
        return edificada;
    }
    
    private void eliminarDeMisPropiedades(TituloPropiedad titulo){
        
        propiedades.remove(titulo);
        titulo.setPropietario(null);
        
    }
    
    private boolean esDeMiPropiedad(TituloPropiedad titulo){
        
        boolean resultado = false;
        
        for(TituloPropiedad propiedad: propiedades){
            
            if(propiedad.getNombre() == titulo.getNombre())
                resultado = true;
            
        }
        
        return resultado;
    }
    
    boolean estoyEnCalleLibre(){
        
        boolean resultado = false;
        
        return resultado;
    }
    
    Sorpresa getCartaLibretad(){
        
        return this.cartaLibertad;
        
    }
    
    Casilla getCasillaActual(){
        
        return this.casillaActual;
        
    }
    
    boolean getEncarcelado(){

        return this.encarcelado;
        
    }
    
    String getNombre(){
 
        return this.nombre;
 
    }
    
    ArrayList<TituloPropiedad> getPropiedades(){

        return this.propiedades;
        
    }
    
    public int getSaldo(){
        
        return this.saldo;
        
    }
   
    void hipotecarPropiedad(TituloPropiedad titulo){
           
        int costeHipoteca = titulo.hipotecar();
        
        modificarSaldo(costeHipoteca);
        
    }
    
    void irACarcel(Casilla casilla){
              
        setCasillaActual(casilla);
            
        setEncarcelado(true);
        
    }
    
    int modificarSaldo(int cantidad){
        
        this.saldo = this.saldo + cantidad;
        
        return this.saldo;
    }
    
    int obtenerCapital(){
        
        int capital = 0;
        
        capital = getSaldo();
        
        for(TituloPropiedad propiedad: propiedades){
            
            capital += propiedad.getPrecioCompra();
            capital += propiedad.getNumCasas()   * propiedad.getPrecioEdificar();
            capital += propiedad.getNumHoteles() * propiedad.getPrecioEdificar();
            if(propiedad.getHipotecado())
                capital -= propiedad.getHipotecaBase();
            
        }
        
        return capital;
    }
   
    ArrayList<TituloPropiedad> obtenerPropiedades(boolean hipoteca){
        
        ArrayList<TituloPropiedad> resultado = new ArrayList<>();
        
        if(hipoteca == true){
            
            for(TituloPropiedad propiedad: propiedades){
                
                if(propiedad.getHipotecado())
                    resultado.add(propiedad);
                
            }
            
        }else{
            
            for(TituloPropiedad propiedad: propiedades){
                
                if(!propiedad.getHipotecado())
                    resultado.add(propiedad);
                
            }
            
        }
        
        return resultado;
    }
    
    void pagarAlquiler(){
        
        int costeAlquiler = casillaActual.getTitulo().pagarAlquiler();
       
        modificarSaldo(-costeAlquiler);
        
    }
    
    protected void pagarImpuesto(){
        this.saldo = this.saldo - casillaActual.getCoste();
    }
    
    void pagarLibertad(int cantidad){
        
        boolean tengoSaldo = tengoSaldo(cantidad);
        
        if(tengoSaldo){
            
            setEncarcelado(false);
            modificarSaldo(-cantidad);
            
        }        
        
    }
    
    void setCartaLibertad(Sorpresa carta){
        
        this.cartaLibertad = carta;
        
    }
    
    void setCasillaActual(Casilla casilla){
        
        this.casillaActual = casilla;
        
    }
    
    void setEncarcelado(boolean encarcelado){
        
        this.encarcelado = encarcelado;
        
    }
    
    boolean tengoCartaLibertad(){
        
        boolean resultado = false;

        if(this.cartaLibertad != null)
            resultado = true;
        
        return resultado;
    }
    
    protected boolean tengoSaldo(int cantidad){
        
        boolean respuesta = false;
        
        if(this.saldo > cantidad)
            respuesta = true;
        
        return respuesta;
    }
    
    void venderPropiedad(Casilla casilla){
        
        TituloPropiedad titulo = casilla.getTitulo();
        
        eliminarDeMisPropiedades(titulo);
        
        int precioVenta = titulo.calcularPrecioVenta();
        
        modificarSaldo(precioVenta);
        
    }
    
    protected boolean puedoEdificarCasa(TituloPropiedad titulo){
        
        boolean respuesta = false;
        
        if(titulo.getNumCasas() < 4)
            respuesta = true;
        
        return respuesta;
    }
    
    protected boolean puedoEdificarHotel(TituloPropiedad titulo){
        
        boolean respuesta = false;
        
        if(titulo.getNumCasas() == 4 && titulo.getNumHoteles() < 4)
            respuesta = true;
        
        return respuesta;
    }
    
    
    
    @Override
    public String toString() {
        
        String resultado = "";
        
        resultado += "Encarcelado: " + this.encarcelado + " Nombre: " + this.nombre + " Saldo: " + this.saldo + "\n";
        resultado += "Casilla actual: " + casillaActual.toString() + "\n";
        if(cartaLibertad != null){
            resultado += "Carta de libertad: Si \n";
        }
        
        for(TituloPropiedad propiedad : this.propiedades){
            
            resultado += propiedad.toString();
            resultado += "\n";
            
        }
        
        resultado += " Capital: " + obtenerCapital();
        resultado += "\n";
        
        return resultado;
    }
    
    @Override
    public int compareTo (Object otroJugador)
    {
        int otroCapital = ((Jugador) otroJugador).obtenerCapital();
        return otroCapital - obtenerCapital();
    }

}
