/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistatextualqytetet;

//Imports
import controladorqytetet.ControladorQytetet;
import controladorqytetet.OpcionMenu;
import modeloqytetet.Qytetet;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Espectro
 **/
public class VistaTextualQytetet {
 
    static ControladorQytetet controlador = ControladorQytetet.getInstance();
    
    public ArrayList<String> obtenerNombresJugadores(){
        
        ArrayList<String> nombres = new ArrayList<String>();
        
        int numeroJugadores = 0;
        
        Scanner in = new Scanner(System.in);
        
        System.out.println("Ingresa el numero de jugadores");
        
        numeroJugadores = in.nextInt();
        
        System.out.println("Ingresa el nombre de los jugadores");
        
        for(int i = 0; i <= numeroJugadores; i++){
            
            nombres.add(in.nextLine());
            
        }
        
        return nombres;
    }
    
    public int elegirCasilla(int opcionMenu){
        
        ArrayList<Integer> casillasValidas = controlador.obtenerCasillasValidas(opcionMenu);
        ArrayList<String>  casillasValidasTransformadas = new ArrayList();
        int resultado = -1;
        
        if(!casillasValidas.isEmpty()){
        
            for(Integer casillaValida: casillasValidas){
                
                System.out.println(casillaValida.toString());
                casillasValidasTransformadas.add(Integer.toString(casillaValida));
            }
            
            resultado = Integer.parseInt(leerValorCorrecto(casillasValidasTransformadas));
            
        }
        
        return resultado;
    }
    
    public String leerValorCorrecto(ArrayList<String> valoresCorrectos){
        
        String resultado = "";
        
        return resultado;
    }
    
    public int elegirOperacion(){
        
        //Obtengo la lista de operaciones validas
        ArrayList<Integer> listaDeOperacionesValidas = controlador.obtenerOperacionesJuegoValidas(); 
        ArrayList<String> listaDeOperacionesValidasTransformada = new ArrayList();
        int valorCorrecto = 0;
        
        //Transformo la lista de operacions de inta String
        for(Integer operacion: listaDeOperacionesValidas){
        
            listaDeOperacionesValidasTransformada.add(Integer.toString(operacion));
            
        }
        
        valorCorrecto = Integer.parseInt(leerValorCorrecto(listaDeOperacionesValidasTransformada));
        
        
        return valorCorrecto;
    }
    
    public static void main(String[] args){
    
        VistaTextualQytetet ui = new VistaTextualQytetet();
        //Obtengo el nombre de los jugadores
        controlador.setNombreJugadores(ui.obtenerNombresJugadores());
        boolean juegoNoAcabado = true;
        boolean necesitaElegirCasilla = false;
        int operacionElegida,casillaElegida = 0;
        
        while(juegoNoAcabado){
        
            operacionElegida = ui.elegirOperacion();
            necesitaElegirCasilla = controlador.necesitaElegirCasilla(operacionElegida);
            
            if(necesitaElegirCasilla){
            
                casillaElegida = ui.elegirCasilla(operacionElegida);
                
            }else if(!necesitaElegirCasilla || casillaElegida > 0){
            
                System.out.println(controlador.realizarOperacion(operacionElegida, casillaElegida));
                
            }
            
        }
        
        
    }
    
    
}
