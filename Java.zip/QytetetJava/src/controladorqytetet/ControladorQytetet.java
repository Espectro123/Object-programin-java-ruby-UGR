/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladorqytetet;

import modeloqytetet.EstadoJuego;
import modeloqytetet.Qytetet;
import java.util.ArrayList;
import modeloqytetet.MetodoSalirCarcel;

/**
 *
 * @author Espectro
 */
public class ControladorQytetet {
    
    private ArrayList<String> nombreJugadores;
    Qytetet qytetet;
    
    
    private ControladorQytetet(){
        
        nombreJugadores = new ArrayList();
        qytetet = Qytetet.getInstance();
        
    }
    
    public static ControladorQytetet getInstance() {
        return ControladorQytetetHolder.INSTANCE;
    }
    
    private static class ControladorQytetetHolder {

        private static final ControladorQytetet INSTANCE = new ControladorQytetet();
    }
    
    public void setNombreJugadores(ArrayList<String> nombreJugadores){
        
        for(String jugador: nombreJugadores){
        
            this.nombreJugadores.add(jugador);
        
        }
        
    }
    
    public ArrayList<Integer> obtenerOperacionesJuegoValidas(){
    
        ArrayList<Integer> resultado = new ArrayList();
        
        EstadoJuego estado_actual = qytetet.getEstado();
        
        //Si la lista de jugadores esta vacia el juego acaba de comenzar
        if(qytetet.getJugadores() == null){
        
            resultado.add(OpcionMenu.INICIARJUEGO.ordinal());
            
        }else{
        
            if(estado_actual == EstadoJuego.JA_PREPARADO){
            
                resultado.add(OpcionMenu.JUGAR.ordinal());
                
            }else if(estado_actual == EstadoJuego.JA_PUEDEGESTIONAR){
            
                resultado.add(OpcionMenu.VENDERPROPIEDAD.ordinal());
                resultado.add(OpcionMenu.HIPOTECARPROPIEDAD.ordinal());
                resultado.add(OpcionMenu.CANCELARHIPOTECA.ordinal());
                resultado.add(OpcionMenu.EDIFICARCASA.ordinal());
                resultado.add(OpcionMenu.EDIFICARHOTEL.ordinal());
                resultado.add(OpcionMenu.PASARTURNO.ordinal());
                            
            }else if(estado_actual == EstadoJuego.JA_PUEDECOMPRAROGESTIONAR){
            
                resultado.add(OpcionMenu.VENDERPROPIEDAD.ordinal());
                resultado.add(OpcionMenu.HIPOTECARPROPIEDAD.ordinal());
                resultado.add(OpcionMenu.CANCELARHIPOTECA.ordinal());
                resultado.add(OpcionMenu.EDIFICARCASA.ordinal());
                resultado.add(OpcionMenu.EDIFICARHOTEL.ordinal());
                resultado.add(OpcionMenu.PASARTURNO.ordinal());
                resultado.add(OpcionMenu.COMPRARTITULOPROPIEDAD.ordinal());
                
            }else if(estado_actual == EstadoJuego.JA_CONSORPRESA){
            
                resultado.add(OpcionMenu.APLICARSORPRESA.ordinal());
                
            
            }else if(estado_actual == EstadoJuego.JA_ENCARCELADO){
            
                resultado.add(OpcionMenu.PASARTURNO.ordinal());
                
            }else if(estado_actual == EstadoJuego.JA_ENCARCELADOCONOPCIONDELIBERTAD){
            
                resultado.add(OpcionMenu.INTENTARSALIRCARCELPAGANDOLIBERTAD.ordinal());
                resultado.add(OpcionMenu.INTENTARSALIRCARCELTIRANDODADO.ordinal());
                
            }else if(estado_actual == EstadoJuego.ALGUNJUGADORENBANCAROTA){
            
                resultado.add(OpcionMenu.OBTENERRANKING.ordinal());
            
            }
        
        }
        
        
        
        return resultado;
    }
    
    public static boolean necesitaElegirCasilla(int opcionMenu){
    
        return false;
        
    }
    
    public ArrayList<Integer> obtenerCasillasValidas(int opcionMenu){
    
        ArrayList<Integer> resultado = new ArrayList();
        
        return resultado;
    }
    
    public String realizarOperacion(int opcionElegida, int casillaElegida){
    
        
        OpcionMenu estado = OpcionMenu.values()[opcionElegida];
        
        if(estado == OpcionMenu.INICIARJUEGO){
        
            qytetet.inicializarJuego(nombreJugadores);
        
        }else if(estado == OpcionMenu.JUGAR){
        
            qytetet.jugar();
            
        }else if(estado == OpcionMenu.APLICARSORPRESA){
        
            qytetet.aplicarSorpresa();
            
        }else if(estado == OpcionMenu.INTENTARSALIRCARCELPAGANDOLIBERTAD){
        
            qytetet.intentarSalirDeLaCarcel(MetodoSalirCarcel.PAGANDOLIBERTAD);
        
        }else if(estado == OpcionMenu.INTENTARSALIRCARCELTIRANDODADO){
        
            qytetet.intentarSalirDeLaCarcel(MetodoSalirCarcel.TIRANDODADO);
            
        }else if(estado == OpcionMenu.COMPRARTITULOPROPIEDAD){
        
            qytetet.comprarTituloPropiedad();
            
        }else if(estado == OpcionMenu.HIPOTECARPROPIEDAD){
        
            qytetet.hipotecarPropiedad(casillaElegida);
        
        }else if(estado == OpcionMenu.CANCELARHIPOTECA){
        
            
            
        }else if(estado == OpcionMenu.EDIFICARCASA){
        
            qytetet.edificarCasa(casillaElegida);
            
        }else if(estado == OpcionMenu.EDIFICARHOTEL){
        
            qytetet.edificarHotel(casillaElegida);
        
        }else if(estado == OpcionMenu.VENDERPROPIEDAD){
        
            qytetet.venderPropiedad(casillaElegida);
        
        }else if(estado == OpcionMenu.PASARTURNO){
        
            qytetet.siguienteJugador();
        
        }else if(estado == OpcionMenu.OBTENERRANKING){
    
            qytetet.obtenerRanking();
    
        }
        
        
        
        return "";
    }
    
    
}
