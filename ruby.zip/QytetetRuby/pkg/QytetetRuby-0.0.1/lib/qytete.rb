# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "sorpresa"
require_relative "tipo_sorpresa"
require_relative "tablero"
require_relative "dado"
require "singleton"

module Modeloqytetet

class Qytetet
  
  include Singleton
  
  attr_accessor :mazo, :tablero,:carta_actual
  attr_reader :dado,:jugador_actual,:jugadores
  
  #Preguntar sobre como poner la visibilidad de las variables
  def initialize
    @mazo
    @tablero
    @NUM_SORPRESAS = 10
    @PRECIO_LIBERTAD = 200
    @SALDO_SALIDA = 1000
    @MAX_JUGADORES = 4
    @NUM_CASILLAS = 20
    #Variables por realciones con otras clases
    @carta_actual
    @jugadores
    @jugador_actual
    @dado = Dado.instance
  end
  
  #Inicializa el mazo de cartas
  def inicializar_cartas_sorpresa
    
    @mazo = Array.new
    
    #Carta 1
    descripcion = "Un pterodacti se tropieza contigo y te paga una indenizacion de 1000 euros"
    carta = Sorpresa.new(descripcion,1000,TipoSorpresa::PAGARCOBRAR)
    @mazo.push(carta)
    
    #Carta 2
    descripcion = "Un tio con un audi se choca contigo y su abogado te hace pagar 1000 euros"
    carta = Sorpresa.new(descripcion,-1000,TipoSorpresa::PAGARCOBRAR)
    @mazo << carta
    
    #Carta 3
    descripcion = "Haces un chiste sobre un dictador en twitter y el gobierno te envia a la carcel"
    carta = Sorpresa.new(descripcion,tablero.carcel.numero_casilla,TipoSorpresa::IRACASILLA)
    @mazo << carta
    
    #Carta 4
    descripcion = "Los idiotas de tus amigos deciden quedar y tienes que ir a Einstein"
    carta = Sorpresa.new(descripcion,3,TipoSorpresa::IRACASILLA)
    @mazo << carta
    
    #Carta 5
    descripcion = "Te dan la beca erasmus en polopos. Enhrabuena!. LLeva abrigo"
    carta = Sorpresa.new(descripcion,19,TipoSorpresa::IRACASILLA)
    @mazo << carta
    
    #Carta 6
    descripcion = "La junta de andalucia dicta que tus casas estan mal. Paga 100 por cada casa."
    carta = Sorpresa.new(descripcion,-100,TipoSorpresa::PORCASAHOTEL)
    @mazo << carta
    
    #Carta 7
    descripcion = "Pintas graffitis en todas tus casas y las conviertes en una galeria. Ganas 100 por cada casa"
    carta = Sorpresa.new(descripcion,100,TipoSorpresa::PORCASAHOTEL)
    @mazo << carta
    
    #Carta 8
    descripcion = "Tus amiguis te dejan dinero para cenar. Recibes 10 por cada jugador"
    carta = Sorpresa.new(descripcion,10,TipoSorpresa::PORJUGADOR)
    @mazo << carta
    
    #Carta 9
    descripcion = "Tus amiguis te piden el dinero que te dejaron hace tiempo. Pierdas 10 por cada jugador"
    carta = Sorpresa.new(descripcion,-10,TipoSorpresa::PORJUGADOR)
    @mazo << carta
    
    #Carta 10
    descripcion = "El gobierno ha decidido que escanear puertos no es un delito. Sales de la carcel"
    carta = Sorpresa.new(descripcion,0,TipoSorpresa::SALIRCARCEL)
    @mazo << carta
    
  end
  
  def inicializar_tablero
    
    @tablero = Tablero.new
  
  end
  
  def inicializar_juego(nombres)
    
    inicializar_jugadores(nombres)
    inicializar_tablero()
    inicializar_cartas_sorpresa()
    
  end
  
  def inicializar_jugadores(nombres)
    
    for nombre in nombres do
      jugadores.add(Jugador.new(nombre))
    end
    
  end
  
  def to_string()
    
    respuesta = ""
    
    respuesta += "Jugador actual: " + @jugador_actual.nombre + "\n"
    respuesta += "Carta_actual{ " + @carta_actual.to_string + " }\n"
    
    respuesta += "Cartas del mazo: \n"
    
    mazo.each do |carta|
      
      respuesta += carta.to_string + "\n"
      
    end
   
    respuesta += tablero.to_string()
    
    respuesta += "Nombre de los jugadores: \n"
    jugadores.each do |jugador|
      
      respuesta += jugador.nombre + "\n"
      
    end
    
    return respuesta
    
  end
  
end

end