# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "qytetet"
require_relative "sorpresa"
require_relative "tablero"
require_relative "jugador"

module Modeloqytetet

class PruebaQytetet

  #Devuelve un vector con las cartas con valores mayores de 0
  def valor_mayor_que_cero(vector)
    
    resultado = Array.new
    
    vector.each do |carta|
      
      if carta.valor > 0
        resultado.push(carta)
      end
      
    end
    
    return resultado
    
  end
  
  #Devuelve un vector con las cartas de tipo IR A CASILLA
  def sorpresa_de_ir_a_casilla(vector)
    
    resultado = Array.new 
    
    vector.each do |carta|
      
      if carta.tipo == TipoSorpresa::IRACASILLA
        resultado.push(carta)
      end
      
    end
    
    return resultado
    
  end
  
  #Devuelve un vectir con las cartas del tipo especificado
  def obtener_tipo_sorpresa(vector,tipo_sorpresa)
    
    resultado = Array.new 
    
    vector.each do |carta|
      
      if carta.tipo == tipo_sorpresa
        resultado.push(carta)
      end
      
    end
    
    return resultado
    
  end
  
    
  def main
    
    #Sesion 1
    puts "********************* SESION 1 ****************************"

    puts "**************** SESION 2 ************************"
    

    @sesion2 = Qytetet.instance
    @sesion2.inicializar_tablero()
    @sesion2.inicializar_cartas_sorpresa()

    
    tablero = @sesion2.tablero
   
    tablero.casillas.each do |casilla|
      #puts casilla.inspect
      puts casilla.to_string()
    end
    
    puts "Introduca el numero de Jugadores: "
    numero_jugadores = gets.chomp.to_i
    jugadores = Array.new 
    
    puts "Introduza el nombre de los " + numero_jugadores.to_s + " jugadores"
    for i in 1..numero_jugadores do
      
      nombre = gets
      jugador = Jugador.new(nombre)
      jugadores << jugador
            
    end
    
    jugadores.each do |jugador|
      
      puts jugador.nombre
      
    end
    
      #Sesion 3
  puts "**************** SESION 3 ************************"
  
  @sesion2.inicializar_juego(jugadores)
    
    if @sesion2.jugador_actual == nil
      
      puts "si"
      
    end
    
    los_jugadores = @sesion2.jugadores
  
    puts "jugador 1: " + los_jugadores[0].nombre.to_s
    
    puts "jugador 2: " + los_jugadores[1].nombre.to_s
    
    jugador_1 = los_jugadores[0]
    
    #Pruebo el metodo mover
    puts "Nombre 1: " + jugador_1.casilla_actual.numero_casilla.to_s
  
    @sesion2.mover(2)
    
    puts "Nombre 1: " + jugador_1.casilla_actual.numero_casilla.to_s
    
    #Pruebo a asignar una propiedad a un jugador y a mover a otro a esa casilla
    
    casilla_a_asignar = @sesion2.tablero.casillas[4]
    
    puts "Casilla" + casilla_a_asignar.titulo.nombre.to_s
    
    casilla_a_asignar.asignar_propietario(jugador_1)
    
    puts "JU_A: " + @sesion2.jugador_actual.nombre.to_s
    
    @sesion2.siguiente_jugador()
    
    puts "JU_A: " + @sesion2.jugador_actual.nombre.to_s
    
    @sesion2.mover(4)
    
    puts "Nombre 2: " + @sesion2.jugador_actual.casilla_actual.numero_casilla.to_s
    puts @sesion2.jugador_actual.saldo.to_s
    
  end
  
  

  
end


prueba = PruebaQytetet.new

prueba.main


end