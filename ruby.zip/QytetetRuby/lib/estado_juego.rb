# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Modeloqytetet
  
  module EstadoJuego
      
    JA_CONSORPRESA = :ja_consorpresa
    
    ALGUNJUGADORENBANCAROTA = :algun_jugadoren_banca_rota
      
    JA_PUEDECOMPRAROGESTIONAR = :ja_puede_comprar_o_gestionar
  
    JA_PUEDEGESTIONAR = :ja_puede_gestionar
    
    JA_PREPARADO = :ja_praparado
    
    JA_ENCARCELADO = :ja_encarcelado
    
    JA_ENCARCELADOCONOPCIONDELIBERTAD = :ja_encarcelado_con_opcion_de_libertad
    
    OBTENERRANKING = :obtener_ranking
    
  end
  
end
