# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "controlador_qytetet"

module Vistatextualqytetet
  
  class VistaTextualQytetet
    
    def initialize
      @controlador = ControladorQytetet.instance
    end
    
    def obtener_nombre_jugadores()
      
      puts "Introduca el numero de Jugadores: "
      numero_jugadores = gets.chomp.to_i
      jugadores = Array.new 

      puts "Introduza el nombre de los " + numero_jugadores.to_s + " jugadores"
      for i in 1..numero_jugadores do

        nombre = gets
        jugador = Jugador.new(nombre)
        jugadores << jugador

      end
      
      return jugadores
    end
    
    def elegir_casilla(opcion_menu)
      
      casillas_validas = @controlador.obtener_casillas_validas(opcion_menu)
      resultado = -1
      
      if(casillas_validas.empty?)
        
        casillas_validas.each do |casilla|
          
          puts casilla.to_string
          
          
        end
        
        resultado = leer_valor_correcto(casillas_validas)
      
      end
      
      return resultado
    end
    
    def leer_valor_correcto(valores_correctos)
      
    end
    
    def elegir_operacion()
      
      lista_de_operaciones_validas = @controlador.obtener_operaciones_juego_validas()
      
      valor_correcto = 0
      
      lista_de_operaciones_validas.each do |opcion|
        
        lista_de_operaciones_en_string << opcion.to_s
        
      end
      
      valor_correcto = leer_valor_correcto(lista_de_operaciones_en_string)
      
      return valor_correcto
    end
    
    def main
      
      vista = VistaTextualQytetet.new
      @controlador.set_nombre_jugadores(vista.obtener_nombre_jugadores())
      operacion_elegida = 0
      casilla_elegida   = 0
      necesita_elegir_casilla = false
      
      while true do
        
        operacion_elegida = vista.elegir_operacion()
        
        necesita_elegir_casilla = @controlador.necesita_elegir_casilla(operacion_elegida)
        
        if(necesita_elegir_casilla)
          casilla_elegida = vista.elegir_casilla(operacion_elegida)
        end
        
        if(!necesita_elegir_casilla or casilla_elegida >= 0)
          puts @controlador.realizar_operacion(operacion_elegida, casilla_elegida)
        end
        
      end
      
      
    end
    
  end
end
