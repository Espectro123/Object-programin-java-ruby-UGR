# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "sorpresa"
require_relative "tipo_sorpresa"
require_relative "tablero"
require_relative "dado"
require_relative "estado_juego"
require_relative "casilla"
require "singleton"

module Modeloqytetet

class Qytetet
  
  include Singleton
  
  attr_accessor :mazo, :tablero,:carta_actual,:estado_juego,:jugadores
  attr_reader :dado,:jugador_actual
  
  #Preguntar sobre como poner la visibilidad de las variables
  def initialize
    @mazo
    @tablero = Tablero.new
    @NUM_SORPRESAS = 10
    @PRECIO_LIBERTAD = 200
    @SALDO_SALIDA = 1000
    @MAX_JUGADORES = 4
    @NUM_CASILLAS = 20
    #Variables por realciones con otras clases
    @carta_actual
    @jugadores = Array.new
    @jugador_actual
    @dado = Dado.instance
    @estado_juego = EstadoJuego::JA_PREPARADO
  end
  
  #Inicializa el mazo de cartas
  def inicializar_cartas_sorpresa
    
    @mazo = Array.new
    casilla_carcel = @tablero.carcel.numero_casilla
    #Carta 1
    descripcion = "Un pterodacti se tropieza contigo y te paga una indenizacion de 1000 euros"
    carta = Sorpresa.new(descripcion,1000,TipoSorpresa::PAGARCOBRAR)
    @mazo.push(carta)
    
    #Carta 2
    descripcion = "Un tio con un audi se choca contigo y su abogado te hace pagar 1000 euros"
    carta = Sorpresa.new(descripcion,-1000,TipoSorpresa::PAGARCOBRAR)
    @mazo << carta
    
    #Carta 3
    descripcion = "Haces un chiste sobre un dictador en twitter y el gobierno te envia a la carcel"
    carta = Sorpresa.new(descripcion,casilla_carcel,TipoSorpresa::IRACASILLA)
    @mazo << carta
    
    #Carta 4
    descripcion = "Los idiotas de tus amigos deciden quedar y tienes que ir a Einstein"
    carta = Sorpresa.new(descripcion,3,TipoSorpresa::IRACASILLA)
    @mazo << carta
    
    #Carta 5
    descripcion = "Te dan la beca erasmus en polopos. Enhrabuena!. LLeva abrigo"
    carta = Sorpresa.new(descripcion,19,TipoSorpresa::IRACASILLA)
    @mazo << carta
    
    #Carta 6
    descripcion = "La junta de andalucia dicta que tus casas estan mal. Paga 100 por cada casa."
    carta = Sorpresa.new(descripcion,-100,TipoSorpresa::PORCASAHOTEL)
    @mazo << carta
    
    #Carta 7
    descripcion = "Pintas graffitis en todas tus casas y las conviertes en una galeria. Ganas 100 por cada casa"
    carta = Sorpresa.new(descripcion,100,TipoSorpresa::PORCASAHOTEL)
    @mazo << carta
    
    #Carta 8
    descripcion = "Tus amiguis te dejan dinero para cenar. Recibes 10 por cada jugador"
    carta = Sorpresa.new(descripcion,10,TipoSorpresa::PORJUGADOR)
    @mazo << carta
    
    #Carta 9
    descripcion = "Tus amiguis te piden el dinero que te dejaron hace tiempo. Pierdas 10 por cada jugador"
    carta = Sorpresa.new(descripcion,-10,TipoSorpresa::PORJUGADOR)
    @mazo << carta
    
    #Carta 10
    descripcion = "El gobierno ha decidido que escanear puertos no es un delito. Sales de la carcel"
    carta = Sorpresa.new(descripcion,0,TipoSorpresa::SALIRCARCEL)
    @mazo << carta
    
    #Carta 11
    descripcion = "Te conviertes en Especulador con uan fianza de 3000"
    carta = Sorpresa.new(descripcion,3000,TipoSorpresa::CONVERTIRME)
    @mazo << carta
    
    #Carta 12
    descripcion = "Te conviertes en Especulador con uan fianza de 5000"
    carta = Sorpresa.new(descripcion,5000,TipoSorpresa::CONVERTIRME)
    @mazo << carta
    
  end
  
  def inicializar_tablero
    
    @tablero = Tablero.new
  
  end
  
  def inicializar_juego(nombres)
    
    inicializar_jugadores(nombres)
    inicializar_tablero()
    inicializar_cartas_sorpresa()
    salida_jugadores();
    
  end
  
  def inicializar_jugadores(nombres)
    
    for nombre in nombres do
      @jugadores.push(Jugador.new(nombre))
    end
    
  end
  
  def to_string()
    
    respuesta = ""
    
    respuesta += "Jugador actual: " + @jugador_actual.nombre + "\n"
    respuesta += "Carta_actual{ " + @carta_actual.to_string + " }\n"
    
    respuesta += "Cartas del mazo: \n"
    
    @mazo.each do |carta|
      
      respuesta += carta.to_string + "\n"
      
    end
   
    respuesta += @tablero.to_string()
    
    respuesta += "Nombre de los jugadores: \n"
    @jugadores.each do |jugador|
      
      respuesta += jugador.nombre + "\n"
      
    end
    
    return respuesta
    
  end
  
  def set_estado_juego(estado_juego)
    
    @estado_juego = estado_juego
    
  end
  
  def actuar_si_en_casilla_edificable()
    
    deboPagar = @jugador_actual.debo_pagar_alquiler()
    tengo_propietario = false
    
    if deboPagar
      
      @jugador_actual.pagar_alquiler()
      
      if(@jugador_actual.saldo <= 0)
        
        set_estado_juego(EstadoJuego::ALGUNJUGADORENBANCARROTA)
        
      end
      
    end
    
    casilla = obtener_casilla_jugador_actual()
    
    tengo_propietario = casilla.tengo_propietario()
    
    if @estado_juego != EstadoJuego::ALGUNJUGADORENBANCAROTA
      
      if tengo_propietario
        
        set_estado_juego(EstadoJuego::JA_PUEDEGESTIONAR)
        
      else
      
        set_estado_juego(EstadoJuego::JA_PUEDECOMPRAROGESTIONAR)
        
      end
      
    end
    
  end
  
  def actuar_si_en_casilla_no_edificable()
    
    set_estado_juego(EstadoJuego::JA_PUEDEGESTIONAR)
    
    casilla_actual = @jugador_actual.casilla_actual
    
    if casilla_actual.tipo == TipoCasilla::IMPUESTO
      
      @jugador_actual.pagar_impuesto()
      
        if(@jugador_actual.saldo <= 0)
        
          set_estado_juego(EstadoJuego::ALGUNJUGADORENBANCARROTA)
        
        end
      
    elsif casilla_actual.tipo == TipoCasilla::JUEZ
    
      encarcelar_jugador()
      
    elsif casilla_actual.tipo == TipoCasilla::SORPRESA
      
      @carta_actual = @mazo.shift()
      
      set_estado_juego(EstadoJuego::JA_CONSORPRESA)
      
    end
    
  end
  
  def hipotecar_propiedad(numero_casilla)
    
    casilla = @tablero.obtener_casilla_numero(numero_casilla)
    
    titulo = casilla.titulo
    
    @jugador_actual.hipotecar_propiedad(titulo)
    
  end
  
  def aplicar_sorpresa
    
    set_estado_juego(EstadoJuego::JA_PUEDEGESTIONAR)
    
    if @carta_actual.tipo == TipoSorpresa::SALIRCARCEL
      
      @jugador_actual.carta_libertad = @carta_actual
      
    elsif @carta_actual.tipo == TipoSorpresa::PAGARCOBRAR
    
      @jugador_actual.modificar_saldo(@carta_actual.valor)
      
      if(@jugador_actual.saldo <= 0)
        
          set_estado_juego(EstadoJuego::ALGUNJUGADORENBANCARROTA)
        
      end
      
    elsif @carta_actual.tipo == TipoSorpresa::IRACASILLA  
      
      valor = @carta_actual.valor
      
      casilla_carcel = @tablero.es_casilla_carcel(valor)
      
      if casilla_carcel
       
        encarcelar_jugador()
        
      else  
      
        mover(valor)
        
      end
      
    elsif @carta_actual.tipo == TipoSorpresa::PORCASAHOTEL
    
      cantidad = @carta_actual.valor
      
      numero_total = @jugador_actual.cuantas_casas_hoteles_tengo()
      
      @jugador_actual.modificar_saldo(cantidad*numero_total)
      
      if(@jugador_actual.saldo <= 0)
        
          set_estado_juego(EstadoJuego::ALGUNJUGADORENBANCARROTA)
        
      end
   
    elsif @carta_actual.tipo == TipoSorpresa::PORJUGADOR
      
      @jugadores.each do |jugador|
        
        if jugador != @jugador_actual
          
          jugador.modificar_saldo(@carta_actual.valor)
          
          if(jugador.saldo <= 0)
        
            set_estado_juego(EstadoJuego::ALGUNJUGADORENBANCARROTA)
        
          end
          
          @jugador_actual.modificar_saldo(-carta_actual.valor)
          
          if(@jugador_actual.saldo <= 0)
        
            set_estado_juego(EstadoJuego::ALGUNJUGADORENBANCARROTA)
        
          end
          
        end
        
      end
      
    elsif @carta_actual.tipo == TipoSorpresa::CONVERTIRME
    
      especulador = @jugador_actual.convertirme(@carta_actual.valor) 
      
      posicion_jugador = obtener_numero_jugador_actual()
      
      @jugadores[posicion_jugador] = especulador
      
    end
      
  end
  
  def obtener_numero_jugador_actual()
    
    continua = true;
    numero = 0
    
    @jugadores.each do |jugador|
      
      if(jugador != @jugador_actual and continua)
        
        numero = numero + 1
        
      else
      
        continua = false
        
      end
      
    end
    
    return numero
  end
  
  def comprar_titulo_propiedad()
    
    coste_compra = @jugador_actual.casilla_actual.valor
    comprado = false
    
    if coste_compra < @jugador_actual.saldo
      
      titulo = @jugador_actual.casilla_actual.asignar_propietario(jugador)
      
      comrpado = true
      
      @jugador_actual.propiedades.push(titulo)
      
      @jugador_actual.modificar_saldo(-coste_compra)
      
    end
    
    if comprado
      
      set_estado_juego(EstadoJuego::JA_PUEDEGESTIONAR)
      
    end
    
    return comprado
    
  end
  
  def edificar_casa(numero_casilla)
    
    edificada = false
    
    casilla = @tablero.casillas[numero_casilla]
    
    titulo = casilla.titulo
    
    edificada = @jugador_actual.edificar_casa(titulo)
    
    if(edificada)

      set_estado_juego(EstadoJuego::JA_PUEDEGESTIONAR)

    end

    return edificada
    
  end
  
  def obtener_casilla_jugador_actual()
    return @jugador_actual.casilla_actual
  end
  
  def encarcelar_jugador()
    
    if !@jugador_actual.debo_ir_a_carcel()
      
      casilla_carcel = @tablero.carcel
      
      @jugador_actual.ir_a_carcel(casilla_carcel)
      
      set_estado_juego(EstadoJuego::JA_ENCARCELADO)
      
    else
      
      carta = @jugador_actual.devolver_carta_libertad()
      
      @mazo.push(carta)
     
      set_estado_juego(EstadoJuego::JA_PUEDEGESTIONAR)
      
    end
    
    
  end
  
  def intentar_salir_de_la_carcel(metodo)
    
    encarcelado = true
    
    if metodo == MetodoSalirCarcel::TIRANDODADO
    
      resultado = tirar_dado()
      
      if resultado >= 5
      
        @jugador_actual.encarcelado = false
        
      end
        
        
    elsif metodo == MetodoSalirCarcel::PAGANDOLIBERTAD
    
      jugador_actual.pagar_libertad(@PRECIO_LIBERTAD)
      
    end
    
    encarcelado = jugador_actual.encarcelado
    
    if encarcelado
      
      set_estado_juego(EstadoJuego::JA_ENCARCELADO)
      
    else
      
      set_estado_juego(EstadoJuego::JA_PREPARADO)
      
    end
    
    
    return !encarcelado
  end
  
  def tirar_dado()
    return @dado.tirar();
  end
  
  def mover(numero_casilla_destino)
    
    casilla_inicial = @jugador_actual.casilla_actual
    
    casilla_final = @tablero.obtener_casilla_numero(numero_casilla_destino)
    
    @jugador_actual.casilla_actual = casilla_final
    
    if numero_casilla_destino < casilla_inicial.numero_casilla
      
      @jugador_actual.modificar_saldo(@SALDO_SALIDA)
      
    end
    
    if casilla_final.soy_edificable
      
      actuar_si_en_casilla_edificable()
      
    else
      
      actuar_si_en_casilla_no_edificable()
      
    end
    
  end
  
  def vender_propiedad(numero_casilla)
    
    casilla = @tablero.obtener_casilla_numero(numero_casilla)
    
    @jugador_actual.vender_propiedad(casilla)
    
    set_estado_juego(EstadoJuego::JA_PUEDEGESTIONAR)
    
  end
  
  def salida_jugadores()
    
    @jugadores.each do |jugador|
      
      jugador.casilla_actual = @tablero.casillas[0]
      
    end
    
    @jugador_actual = @jugadores[0]
    
  end
  
  def siguiente_jugador()
    
    posicion = 0
    encontrado = true
    
    @jugadores.each do |jugador|
      
      if jugador != @jugador_actual
        
        encontrado = false
        
      elsif encontrado
        
        posicion = posicion + 1
        
      end
      
    end
    
      posicion = (posicion+2)%@jugadores.length
      
      @jugador_actual = @jugadores[posicion]
      
      if @jugador_actual.encarcelado
      
        set_estado_juego(EstadoJuego::JA_ENCARCELADOCONOPCIONDELIBERTAD) 
        
      else
      
        set_estado_juego(EstadoJuego::JA_PREPARADO)
        
      end
    
  end
  
end

end