# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Modeloqytetet
  
  class OtraCasilla < Casilla
    
    attr_accessor :titulo,:tipo
    
    def initialize
      @titulo = nil
    end
    
    def self.ini_casilla_especial(*args)
    
      casilla = allocate
      casilla.init_especial(*args)
      casilla
    
    end
  
    def init_especial(numero_casilla,tipo)
      @numero_casilla = numero_casilla
      @coste = 0
      @titulo = nil
      @tipo = tipo
    end
    
    def to_string()
    
      resultado = "Casilla: " + @numero_casilla.to_s
      resultado += " Tipo: " + @tipo.to_s

      return resultado
      
    end
  
    def tengo_propietario()
      return false
    end
    
    def soy_edificable()
      return false
    end
    
  end
  
end
