# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "titulo_propiedad"
require_relative "casilla"


module Modeloqytetet

  class Jugador
    
    attr_accessor :carta_libertad, :casilla_actual, :encarcelado
    attr_reader :nombre, :propiedades, :saldo
    
    
    
    def initialize(nombre)
      @encarcelado = false
      @nombre = nombre
      @saldo = 7500
      @carta_libertad = nil
      @casilla_actual
      @propiedades = Array.new
    end
    
    def cancelar_hipoteca(titulo_propiedad)
      
    end

    def comprar_titulo_propiedad()
      
    end
    
    #Aqui
    
    def convertirme(fianza)
      
      especulador = Especulador.ini_especulador(self,fianza)
      return respeculador
    end
    
    def debo_ir_a_carcel()
      return !tengo_carta_libretad()
    end
    
    def pagar_impuesto()
      @saldo = @saldo - @casilla_actual.coste
    end
    
    def puedo_edificar_casa(titulo)
      
      respuesta = false
      
      if(@saldo >=  titulo.precio_edificar and titulo.num_casas < 4)
        respuesta = true
      end
      
      return respuesta
      
    end
    
    def puedo_edificar_hotel(titulo)
      
      respuesta = false
      
      if(@saldo >= titulo.precio_edificar and titulo.num_casas == 4 and titulo.num_hoteles < 4)
        respuesta = true
      end
      
      return respuesta
    end
    
    def tengo_saldo()
      
      
    end
    
    #hasta aqui
    
    def cuantas_casas_hoteles_tengo()
      
      numero_de_casas_hoteles = 0
      
      @propiedades.each do |propiedad|
        
        numero_de_casas_hoteles += propiedad.num_casas
        numero_de_casas_hoteles += propiedad.num_hoteles
        
      end
      
      return numero_de_casas_hoteles
      
    end
    
    def debo_pagar_alquiler()
      
        debo_pagar = false;
        es_de_mi_propiedad = false;
        tiene_propietario = false;
        esta_hipotecada = false;
        esta_encarcelado = false;
        
        titulo = @casilla_actual.titulo
      
      
        es_de_mi_propiedad = es_de_mi_propiedad(titulo)
        
        if !es_de_mi_propiedad
          
          tiene_propietario = titulo.tengo_propietario()
          
          if tiene_propietario
            
            esta_encarcelado = titulo.propietario_encarcelado()
          
            if !esta_encarcelado
              
              esta_hipotecada = titulo.hipotecado
              
              if !esta_hipotecada 
                
                debo_pagar = true
              
              end
            
            end
          
          end
        
        end
      
      return debo_pagar
    end
    
    def devolver_carta_libertad()
      
    end
    
    def edificar_casa(titulo)
      
      edificada = false
      
      num_casas = titulo.num_casas
      
      coste_edificar_casa = titulo.precio_edificar
      
      tengo_saldo = tengo_saldo(coste_edificar_casa)
      
      if tengo_saldo == true
        
        titulo.edificar_casa()
        
        edificada = true;
        
        modificar_salfo(-coste_edificar_casa)
        
      end
      
      
      
      
    end
    
    def edificar_hotel(titulo)
      
    end
    
    def eliminar_de_mis_propiedades(titulo)
        @propiedades.delete(titulo);
        titulo.propietario = nil;
    end
    
    def es_de_mi_propiedad(titulo)
      
      respuesta = false
      
      @propiedades.each do |propiedad|
        
        if propiedad.nombre == titulo.nombre
          respuesta = true
        end
        
      end
      
      return respuesta
    end
    
    def estoy_en_calle_libre()
      
    end
    
    def hipotecar_propiedad(titulo)
      
      coste_hipoteca = titulo.hipotecar()
      
      modificar_saldo(coste_hipoteca)
      
    end
    
    def ir_a_carcel(casilla)
      
      @casilla_acutal = casilla
      
      encarcelado = true
      
    end
    
    def modificar_saldo(cantidad)
      @saldo = @saldo + cantidad
    end
    
    def obtener_capital()
    
    end
    
    def obtener_propiedades(estadoHipoteca)
      
      propiedades_encontradas = Array.new
      
      if(estadoHipoteca)
        
        @propiedades.each do |propiedad|
          
          if(propiedad.hipotecado)
            propiedades_encontradas << propiedad
          end
          
        end
        
      else
      
       propiedades.each do |propiedad|
          
          if(!propiedad.hipotecado)
            propiedades_encontradas << propiedad
          end
          
        end
        
      end
      
      return propiedades_encontradas
    end
    
    def pagar_alquiler()
      
      coste_alquiler = @casilla_actual.titulo.pagar_alquiler()
      
      modificar_saldo(-coste_alquiler)
      
    end
    
    def pagar_impuesto()
      @saldo = @saldo - @casilla_actual.coste
    end
    
    def pagar_libertad(cantidad)
      
      tengo_saldo = tengo_saldo(cantidad)
      
      if tengo_saldo
        
        @encarcelado = false
        
        modificar_saldo(-cantidad)
        
      end
      
    end
    
    def tengo_carta_libertad()
        
      respuesta = false
      
      if @carta_libertad != nil
        respuesta = true
      end
      
      return respuesta
    end
    
    def tengo_saldo(cantidad)
      
      resultado = false
      
      if @saldo > cantidad
        resultado = true
      end
      
      return resultado
    end
    
    def vender_propiedad(casilla)
      
      titulo = casilla.titulo
      
      eliminar_de_mis_propiedades(titulo)
      
      precio_venta = titulo.calcular_precio_venta()
      
      modificar_saldo(precio_venta)
      
    end
    
    def obtener_capital
        
      capital = 0
      
      @propiedades.each do |propiedad|
        
        if propiedad.hipotecado == false
          capital += propiedad.precio_compra
          capital += propiedad.num_casas * propiedad.precio_edificar
          capital += propiedad.num_hoteles * propiedad.precio_edificar
        else
          capital += propiedad.hipoteca_base*(-1)
        end
          
      end
      
        capital = capital + @saldo
      
      return capital
    end
    
    #Imprime la clase jugador con el nombre de sus propiedades
    def to_string()
      
      respuesta = ""
      
      respuesta += "Nombre: " + @nombre + " Encarcelado: " + @encarcelado + " Saldo: " + @saldo + "\n"
      respuesta += " Carta libtertad{ " + @carta_libertad.to_string + " } \n"
      respuesta += " Casilla actual { " + @casilla_actual.to_string + " } \n"
      
      if @propiedades != nil
        
        @propiedades.each do |propiedad|
       
        respuesta += propiedad.nombre + ", "
        
     end
      
      end
      
      respuesta += " Capital: " + self.obtener_capital + "\n"
      
      
      return respuesta
      
    end
    
    def <=>(otroJugador)
      
      otro_capital = otroJugador.obtener_capital
      mi_capital = obtener_capital
      resultado = 0
      
      if otro_capital > mi_capital
        
        resultado = 1
        
      elsif otro_capital < mi_capital
      
        resultado = -1
 
      end
      
      return resultado
    end
    
  end


end