# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.



module Modeloqytetet

class TituloPropiedad
  
  #Atributos privados de la clase
  attr_accessor :nombre, :factor_revalorizacion, :precio_compra , :alquiler_base, :hipoteca_base
  
  attr_accessor :precio_edificar, :num_casas, :num_hoteles, :propietario
  
  attr_accessor :hipotecado,:titulo

  
  #Constructor
  def initialize(nombre,factor,compra,alquiler,hipoteca,edificar)
    @nombre = nombre
    @hipotecado = false
    @factor_revalorizaion = factor
    @precio_compra = compra
    @alquiler_base = alquiler
    @hipoteca_base = hipoteca
    @precio_edificar = edificar
    @num_casas = 0
    @num_hoteles = 0
    @titulo
    @propietario = nil
  end
 
  #Devuelve un string con la informacion del objeto
  def to_string()
  
    resultado = "Nombre: " + @nombre + "Hipotecado: " + @hipotecado + "Factor: " + @factor_revalorizacion
    resultado += "\n"
    resultado += "Precio de compra: " + @precio_compra + "Alquiler: " + @alquiler_base + "Hipoteca: " + @hipoteca_base
    resultado += "\n"
    resultado += "Coste edificar: " + @precio_edificar + "Num casas: " + @num_casas + "Num hoteles: " + @num_hoteles
    resultado += "\n"
    resultado += "Propietario: " + @propietario.nombre + "\n"
    
    
    return resultado
    
  end
  
  def calcular_coste_cancelar()
    
  end
  
  def calcular_coste_hipotecar()
    return @hipotecaBase + @numCasas * @hipotecaBase  + @numHoteles * @hipotecaBase;
  end
  
  def calcular_importe_alquiler()
    return @alquiler_base
  end
  
  def calcular_precio_venta()
    return @precioCompra + (@numCasas + @numHoteles) * @precioEdificar * @factorRevalorizacion
  end
  
  def cancelar_hipoteca()
    
  end
  
  def cobrar_alquiler(coste)
    
  end
  
  def edificar_casa()
    
    @num_casas = @num_casas + 1
    
  end
  
  def edificar_hotel()
    
  end
  
  def hipotecar()
    
    @hipotecada = true
    
    return calcular_coste_hipotecar()
    
  end
  
  def pagar_alquiler()
    
    coste_alquiler = calcular_importe_alquiler()
    
    return coste_alquiler
    
  end
  
  def propietario_encarcelado()
    
  end
  
  def tengo_propietario()
    
    respuesta = false
    
    if @propietario != nil
      
      respuesta = true
      
    end
    
    
    return respuesta
  end
  
end


end