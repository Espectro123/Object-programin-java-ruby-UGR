# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require "singleton"
require_relative "interfaz_usuario_qytetet"


module Controladorqytetet
  
  class ControladorQytetet
    
    include Singleton
    include "modeloqytetet"
    
    def initialize
      @nombre_jugadores = Array.new
      @juego = Qytetet.instance
    end
   
    def set_nombre_jugadores(nombre_jugadores)
      
      @nombre_jugadores = nombre_jugadores
      
    end
    
    def obtener_operaciones_juego_validas()
      
      estado = @juego.estado_juego
      
      resultado = Array.new
      
      if(@juego.jugadores == nil)
        
        resultado << OpcionMenu.index(:INICIARJUEGO)
        
      else
      
        if(estado == EstadoJuego::JA_PREPARADO)
          
          resultado << OpcionMenu.index(:JUGAR)          
          
        elsif(estado == EstadoJuego::JA_PUEDEGESTIONAR)
          
          resultado << OpcionMenu.index(:VENDERPROPIEDAD)
          resultado << OpcionMenu.index(:HIPOTECARPROPIEDAD)
          resultado << OpcionMenu.index(:CANCELARHIPOTECA)
          resultado << OpcionMenu.index(:EDIFICARCASA)
          resultado << OpcionMenu.index(:EDIFICARHOTEL)
          resultado << OpcionMenu.index(:PASARTURNO)
          
          
        elsif(estado == EstadoJuego::JA_PUEDECOMPRARGESTIONAR)
                   
          resultado << OpcionMenu.index(:VENDERPROPIEDAD)
          resultado << OpcionMenu.index(:HIPOTECARPROPIEDAD)
          resultado << OpcionMenu.index(:CANCELARHIPOTECA)
          resultado << OpcionMenu.index(:EDIFICARCASA)
          resultado << OpcionMenu.index(:EDIFICARHOTEL)
          resultado << OpcionMenu.index(:PASARTURNO)
          resultado << OpcionMenu.index(:COMPRARTITULOPROPIEDAD)
          
        elsif(estado == EstadoJuego::JA_CONSORPRESA)
          
          resultado << OpcionMenu.index(:APLICARSORPRESA)
          
        elsif(estado == EstadoJuego::JA_ENCARCELADO)
           
          resultado << OpcionMenu.index(:PASARTURNO)
          
        elsif(estado == EstadoJuego::JA_ENCARCELADOCONOPCIONDELIBERTAD)
          
          resultado << OpcionMenu.index(:INTENTARSALIRCARCELPAGANDOLIBERTAD)
          resultado << OpcionMenu.index(:INTENTARSALIRCARCELTIRANDODADO)
          
        elsif(estado == EstadoJuego::ALGUNJUGADORENBANCARROTA)
          
          resultado << OpcionMenu.index(:OBTENERRANKING)
        
        end
        
      end
      
      return resultado
    end
    
    def necesita_elegir_casilla(opcion_menu)
      
    end
    
    def obtener_casillas_validas(opcion_menu)
      
      
    end
    
    def realizar_operacion(opcion_elegida, casilla_elegida)
      
      estado = OpcionMenu[opcion_elegida]
      
      if(estado == OpcionMenu.index(:INICIARJUEGO))
        
        @juego.inicializar_juego(@nombre_jugadores)
        
      elsif(estado == OpcionMenu.index(:JUGAR))
        
        @juego.jugar()
      
      elsif(estado == OpcionMenu.index(:APLICARSORPRESA))
        
        @juego.aplicar_sorpresa()
        
      elsif(estado == OpcionMenu.index(:INTENTARSALIRCARCELPAGANDOLIBERTAD))
        
        @juego.intentar_salir_de_la_carcel(MetodoSalirCarcel::PAGANDOLIBERTAD)
      
      elsif(estado == OpcionMenu.index(:INTENTARSALIRCARCELTIRANDODADO))
        
        @juego.intentar_salir_de_la_carcel(MetodoSalirCarcel::TIRANDODADO)
        
      elsif(estado == OpcionMenu.index(:COMPRARTITULOPROPIEDAD))
        
        @juego.comprarTituloPropiedad()
        
      elsif(estado == OpcionMenu.index(:HIPOTECARPROPIEDAD))
        
        @juego.hipotecarPropiedad(casilla_elegida)
        
      elsif(estado == OpcionMenu.index(:CANCELARHIPOTECA))
        
      elsif(estado == OpcionMenu.index(:EDIFICARCASA))
        
        @juego.edificar_casa(casilla_elegida)
        
      elsif(estado == OpcionMenu.index(:EDIFICARHOTEL))
        
        @juego.edificar_hotel(casilla_elegida)
        
      elsif(estado == OpcionMenu.index(:VENDERPROPIEDAD))
        
        @juego.vender_propiedad(casilla_elegida)
        
      elsif(estado == OpcionMenu.index(:PASARTURNO))
        
        @juego.siguiente_jugador()       
      
      elsif(estado == OpcionMenu.index(:OBTENERRANKING))
        
        @juego.obtener_ranking()
        
      end
    end
    
  end
  
end
