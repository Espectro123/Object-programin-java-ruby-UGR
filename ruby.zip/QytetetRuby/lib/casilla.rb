# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "titulo_propiedad"

module Modeloqytetet

class Casilla
  
  attr_accessor :numero_casilla, :coste, :tipo

  attr_accessor :titulo
  
  private :titulo=
  
  private_class_method :new
  
  def initialize
    @numero_casilla
    @coste
    @tipo
    @titulo
  end
 
  def to_string()
    
    if @titulo != nil
      resultado = "Casilla: " + @numero_casilla.to_s + " Coste: " + @coste.to_s
      resultado += " Tipo: " + @tipo.to_s + " Titulo: " + @titulo.nombre.to_s
    
    else
      resultado = "Casilla: " + @numero_casilla.to_s
      resultado += " Tipo: " + @tipo.to_s

    end

    return resultado
    
  end
  
  def asignar_propietario(jugador)
    
    @titulo.propietario = jugador
    
  end
  
  def soy_edificable()
    return true
  end
  
  def tengo_propietario()
    
    if @titulo.tengo_propietario
      
      return true
     
    else
      
      return false
      
    end
    
  end
  
end


end