# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.


module Modeloqytetet
  
class Sorpresa
  
  attr_accessor :texto, :valor, :tipo
  
  #Contructor de la clase
  def initialize(texto,valor,tipo)

    @texto = texto
    @valor = valor
    @tipo = tipo
    
  end
  
  #Convierte los valores de la clase a un string
  def to_string
    
    resultado = "Texto: "+ @texto +"\n Valor: "+ @valor.to_s + "\n Tipo: " + @tipo.to_s
    
    return resultado
    
  end
  
end

end