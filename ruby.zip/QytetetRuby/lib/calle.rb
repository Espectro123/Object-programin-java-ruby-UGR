# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Modeloqytetet
  
  class Calle < Casilla
    
    attr_accessor :numero_casilla, :coste, :tipo
    
    attr_accessor :titulo
  
    private :titulo=
    
    def initialize()
      
    end
    
    def self.ini_casilla_calle(*args)
     
      casilla = allocate
      casilla.init_calle(*args)
      casilla
    
    end
  
  def init_calle(numero_casilla,titulo)
    
    @numero_casilla = numero_casilla
    @titulo = titulo
    @coste = titulo.precio_compra
    @tipo = TipoCasilla::CALLE
    
  end
  
    
    def asignar_propietario(jugador)
      
    end
    
    def pagar_alquiler()
      
    end
    
    def set_titulo(titulo)
      @titulo = titulo
    end
    
    def soy_edificable()
      
    end
    
    def tengo_propietario()
      
      if @titulo.tengo_propietario
      
        return true
     
      else
      
        return false
      
      end
      
    end
    
    def to_string()
    
      resultado = "Casilla: " + @numero_casilla.to_s + " Coste: " + @coste.to_s
      resultado += " Tipo: " + @tipo.to_s + " Titulo: " + @titulo.nombre.to_s

      return resultado
    
  end
    
  end
  
end
