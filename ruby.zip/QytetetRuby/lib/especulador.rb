# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Modeloqytetet
  
  class Especulador < Jugador
    
    attr_accessor :fianza
    
    private :fianza=
    
    private :pagar_fianza
    
    def initialize
      @fianza = 0
    end
    
    def self.ini_especulador(*args)
      
      especulador = allocate
      especulador.inicializar_especulador(*args)
      especulador
      
    end
    
    def inicializar_especulador(jugador,fianza)
      
      @carta_libertad = jugador.carta_libertad
      @casilla_actual = jugador.casilla_actual
      @encarcelado    = jugador.encarcelado
      @nombre         = jugador.nombre
      @propiedades    = jugador.propiedades
      @saldo          = jugador.saldo
      @fianza         = fianza
      
    end
    
    protected
    
    def pagar_impuesto()
    
      @saldo = @saldo - (@casilla_actual.coste/2)
            
    end
    
    def convertirme()
      
    end
      
    def debo_ir_a_carcel()
      
      respuesta = false
      
      if(super.debo_ir_a_carcel and !pagar_fianza())
        respuesta = true
      end
        
      return respuesta
    end
    
    def pagar_fianza()
      
      respuesta = false
      
      if(@saldo >= fianza)
        respuesta = true
        @saldo = @saldo - fianza
      end
      
      return respuesta
    end
    
    def puedo_edificar_casa()
            
      respuesta = false
      
      if(@saldo >=  titulo.precio_edificar and titulo.num_casas < 8)
        respuesta = true
      end
      
      return respuesta
    end
    
    def puedo_edificar_hotel()
      
      respuesta = false
      
      if(@saldo >= titulo.precio_edificar and titulo.num_casas >= 4 and titulo.num_hoteles < 8)
        respuesta = true
      end
      
      return respuesta
      
    end
    
  end
  
end
