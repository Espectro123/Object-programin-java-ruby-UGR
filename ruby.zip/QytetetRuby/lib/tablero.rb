# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "casilla"
require_relative "titulo_propiedad"
require_relative "tablero"
require_relative "tipo_casilla"
require_relative "titulo_propiedad"
require_relative "otra_casilla"
require_relative "calle"

module Modeloqytetet

class Tablero
  
  attr_accessor :casillas, :carcel
  
  def initialize
    @casillas = Array.new
    @carcel
    inicializar()
  end
  
  #Inicializa el tablero del juego
  def inicializar()
  
    
    #Casilla de salida
    casilla = OtraCasilla.ini_casilla_especial(0,TipoCasilla::SALIDA)
    @casillas << casilla
    
    #Casilla La parra
    titulo = TituloPropiedad.new("La parra",0.5,300,100,200,50)
    casilla = Calle.ini_casilla_calle(1,titulo)
    @casillas << casilla
    
    #Casilla Las Jarras
    titulo = TituloPropiedad.new("Las jarras",1.0,600,230,400,120)
    casilla = Calle.ini_casilla_calle(2,titulo)
    @casillas << casilla
    
    #Casilla Sorpresa
    casilla = OtraCasilla.ini_casilla_especial(3,TipoCasilla::SORPRESA)
    @casillas << casilla
    
    #Casilla La academia
    titulo = TituloPropiedad.new("La academia",1.5,1200,400,800,250)
    casilla = Calle.ini_casilla_calle(4,titulo)
    @casillas << casilla
    
    #Casilla El continental
    titulo = TituloPropiedad.new("El continental",1.0,1800,600,1200,350)
    casilla = Calle.ini_casilla_calle(5,titulo)
    @casillas << casilla
    
    #Casilla EL dominos
    titulo = TituloPropiedad.new("El dominos",2.0,2500,900,2000,500)
    casilla = Calle.ini_casilla_calle(6,titulo)
    @casillas << casilla
    
    #Casilla Impuesto
    casilla = OtraCasilla.ini_casilla_especial(7,TipoCasilla::IMPUESTO) 
    @casillas << casilla
    
    #Casilla Erasmus
    titulo  = TituloPropiedad.new("Erasmus",5.0,5000,1000,3500,3000)
    casilla = Calle.ini_casilla_calle(8,titulo)
    @casillas << casilla

    #Casilla carcel
    casilla = OtraCasilla.ini_casilla_especial(9,TipoCasilla::CARCEL)
    @carcel = casilla
    
    #Casilla Memes de gatos
    titulo = TituloPropiedad.new("Memes de gatos",2.5,3000,1200,2200,700)
    casilla = Calle.ini_casilla_calle(10,titulo)
    @casillas << casilla
    
    #Casilla de Memes de pelis
    titulo = TituloPropiedad.new("Memes de pelis",3.0,4000,1800,3200,1000)
    casilla = Calle.ini_casilla_calle(11,titulo)
    @casillas << casilla
    
    #Casilla SORPRESA
    casilla = OtraCasilla.ini_casilla_especial(12,TipoCasilla::SORPRESA)
    @casillas << casilla
    
    #Casilla PARKING
    casilla = OtraCasilla.ini_casilla_especial(13,TipoCasilla::PARKING)
    @casillas << casilla
    
    
    #Casilla Chocobos
    titulo = TituloPropiedad.new("Chocobos",0.0,5000,4000,4200,1500)
    casilla = Calle.ini_casilla_calle(14,titulo)
    @casillas << casilla
    
    #Casilla METALOCALYPSE
    titulo = TituloPropiedad.new("Matalocalypse",10.0,10000,2300,0,1500)
    casilla = Calle.ini_casilla_calle(15,titulo)
    @casillas << casilla
    
    #Casilla SORPRESA
    casilla = OtraCasilla.ini_casilla_especial(16,TipoCasilla::SORPRESA)
    @casillas << casilla
    
    #Casilla Plan Propio
    titulo = TituloPropiedad.new("Plan Propio",5.0,5000,1000,3500,3000)
    casilla = Calle.ini_casilla_calle(17,titulo)
    @casillas << casilla
    
    #Casilla Grado de ingenieria informatica
    titulo = TituloPropiedad.new("Grado de II",12.0,8000,3000,7200,1900)
    casilla = Calle.ini_casilla_calle(18,titulo)
    @casillas << casilla
    
    #Casilla JUEZ
    casilla = OtraCasilla.ini_casilla_especial(19,TipoCasilla::JUEZ)
    @casillas << casilla
    
  end
  
  #Imprime las casillas y la carcel
  def to_string
    
    resultado = "Casillas: "
    
    @casillas.each do |casilla|
      resultado += casilla.to_string()
      resultado += "\n"
    end
    
    resultado += @carcel.to_string() + "\n"
    
    return resultado
  end
  
  def es_casilla_carcel(numeroCasilla)
    
    respuesta = false
    
    if(numeroCasilla == @carcel.numero_casilla)
      respuesta = true
    end
    
    return respuesta
    
  end
  
  def obtener_casilla_numero(numeroCasilla)
    
    return @casillas[numeroCasilla]
  
  end
  
  def obtener_casilla_final(numeroCasilla,desplazamiento)
    
    numero_casilla_final = 0
    
    if((numeroCasilla+desplazamiento) >= @casillas.length)
      numero_casilla_final = (numeroCasilla+desplazamiento)%@casillas.length
    else
      numero_casilla_final = (numeroCasilla+desplazamiento)
    end
    
    return @casillas[numero_casilla_final]
    
  end
  
end


end